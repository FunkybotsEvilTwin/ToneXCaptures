#!/usr/bin/env python3
"""
Prophet-5 Rev 4 SysEx -> u-he RePro-5 .h2p converter v3.1

First-pass converter built for Prophet-5/10 Rev 4 program dumps:
  F0 01 31 02 [group] [program] [152 packed bytes] F7
and edit-buffer dumps:
  F0 01 31 03 [152 packed bytes] F7

Version 0.2 added a loose fallback parser and --scan mode for third-party
soundsets whose SysEx framing differs from the official examples.

Version 0.3 adds embedded-program-name extraction and filename templating so
converted RePro-5 presets can use the original soundset patch names when they
are present in or near each SysEx dump.

Version 0.4 fixes Rev 4 bank files that use device/model ID 0x32 and extracts
the Prophet Rev 4 stored patch-name field from the unpacked program data. The
Luke Neptune VintageClassic bank stores 20-character patch names at unpacked
program bytes 65..84.

Version 0.5 maps Prophet Osc B Fine as unipolar-positive instead of bipolar.

Version 0.6 maps Prophet oscillator coarse frequency bytes to RePro-5 Oct/Freq:
raw 0 = C0 -> Oct 0 / Freq 0.00; raw 24 = C1 -> Oct 1 / Freq 0.00;
each 2 raw Prophet units equals 1 semitone on RePro's -12..+12 Freq knob.

Version 0.8 adds measured filter-model-aware cutoff compensation using Poly as
the baseline and defaults Rev 1/2 to Driven for testing.

Version 0.9 quantizes coarse oscillator frequency offsets to full semitones by
default. This prevents odd Prophet raw values like 25 from becoming RePro
Freq=+0.50; they now map to the lower full semitone by default.

Version 1.0 maps Prophet aftertouch flags into reserved RePro-5 mod matrix
slots: MM1 = Pressure -> Filter:Cutoff, MM2 = Pressure -> GMod:LowLim.
The slots are always assigned, but their depths stay 0.00 unless the Prophet
program has the corresponding aftertouch destination enabled.

Version 1.3 sets the RePro-5 final output control in the main section
(CcOp) to the profile default, 40.00, for every converted preset.

Version 1.4 adds per-source output folders. When converting multiple inputs or
using --all-syx, each SysEx file is written into its own subfolder under --out
by default. Use --flat-output to restore the old single-folder behavior.

Version 1.9 adds stack/split layer detection for newer Prophet-5/10 firmware.
When a program points to a linked layer program, both layers can be converted
as separate RePro-5 presets using shared filename-template fields such as
{pair_label} and {layer}.

Version 2.0 treats obvious placeholder/corrupt names such as "Basic Program",
"Bas", and location strings like "G4_P12" as generic. For stack/split layers,
{name} now falls back to the shared pair label plus layer, e.g. "G4_P01 A".

Version 2.3 exposes stack/split mode labels in filename templates. Observed
firmware mode code 2 is labeled "Stack" and mode code 3 is labeled "Split"
for the {stack_mode} template field.

Version 3.0 adds a narrow oscillator-frequency boundary fix: raw values one
unit below the next C octave, e.g. B0+ raw 23, can map to the next C
instead of +11 without changing raw values just above C such as C1+.

Final 1.0 sets P5 Old oscillator tweaks for Rev 1/2 -> Driven and normalizes octave-boundary results cleanly: if a mapped oscillator
would become Freq=+12 and another RePro octave is available, it is written as
the next Oct with Freq=0 instead. Boundary clamps prevent impossible octaves.

Version 2.6 title-cases regular embedded patch names for filenames while preserving
FM, LN, II, PWM, and GEO. Stack/split generated names are intentionally left
unchanged.

It edits the readable text section of a RePro-5 .h2p template and leaves the
compressed $$$$ block alone. RePro-5 has been confirmed to accept those text edits.

This is intentionally profile-driven: if a control sounds wrong after conversion,
adjust the JSON profile instead of editing code.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Tuple

DSI_ID = 0x01
PROPHET5_ID = 0x31
PROPHET5_ALT_ID = 0x32
PROPHET5_IDS = {PROPHET5_ID, PROPHET5_ALT_ID}
PROGRAM_DUMP = 0x02
EDIT_BUFFER_DUMP = 0x03
EXPECTED_UNPACKED_LEN = 128
EXPECTED_PACKED_LEN = 152
PROPHET_STORED_NAME_OFFSET = 65
PROPHET_STORED_NAME_LEN = 20

# Newer firmware appears to use some of the formerly padded bytes for
# stack/split metadata. These offsets are intentionally conservative and based
# on observed SysEx: primary stack/split programs have mode code 2 or 3 at byte
# 89, linked program at byte 91, and linked group at byte 92.
STACK_SPLIT_MODE_BYTE = 89
STACK_SPLIT_LINKED_PROGRAM_BYTE = 91
STACK_SPLIT_LINKED_GROUP_BYTE = 92

# Prophet Rev 4 unpacked-byte map. The program bytes follow NRPN order.
P = {
    "osc_a_freq": 0,
    "osc_b_freq": 1,
    "osc_b_fine": 2,
    "osc_a_saw": 3,
    "osc_a_square": 4,
    "osc_b_saw": 5,
    "osc_b_tri": 6,
    "osc_b_square": 7,
    "osc_a_pw": 8,
    "osc_b_pw": 9,
    "osc_sync": 10,
    "osc_b_low_freq": 11,
    "osc_b_keyboard": 12,
    "glide_rate": 13,
    "osc_a_level": 14,
    "osc_b_level": 15,
    "noise_level": 16,
    "cutoff": 17,
    "resonance": 18,
    "filter_keytrack": 19,
    "filter_rev": 20,
    "lfo_freq": 21,
    "lfo_initial_amount": 22,
    "lfo_saw": 23,
    "lfo_tri": 24,
    "lfo_square": 25,
    "lfo_source_mix": 26,
    "lfo_freq_a": 27,
    "lfo_freq_b": 28,
    "lfo_pw_a": 29,
    "lfo_pw_b": 30,
    "lfo_filter": 31,
    "poly_mod_filter_env_amount": 32,
    "poly_mod_osc_b_amount": 33,
    "poly_mod_freq_a": 34,
    "poly_mod_pw": 35,
    "poly_mod_filter": 36,
    "vintage": 37,
    "aftertouch_filter": 38,
    "aftertouch_amp": 39,
    "filter_env_amount": 40,
    "velocity_filter": 41,
    "velocity_amp": 42,
    "filter_attack": 43,
    "amp_attack": 44,
    "filter_decay": 45,
    "amp_decay": 46,
    "filter_sustain": 47,
    "amp_sustain": 48,
    "filter_release": 49,
    "amp_release": 50,
    "release_switch": 51,
    "unison_on": 52,
    "unison_voice_count": 53,
}

PARAMETER_NAMES = {v: k for k, v in P.items()}


@dataclass
class ProphetPatch:
    source_index: int
    dump_type: str
    group: Optional[int]
    program: Optional[int]
    data: List[int]
    name: Optional[str] = None
    pair_label: Optional[str] = None
    layer: Optional[str] = None
    stack_split_mode: Optional[str] = None

    @property
    def label(self) -> str:
        if self.dump_type.startswith("program") and self.group is not None and self.program is not None:
            # Display 1-based bank/program names while preserving raw values in report.
            return f"G{self.group + 1}_P{self.program + 1:02d}"
        return f"EditBuffer_{self.source_index:03d}"

    @property
    def display_name(self) -> str:
        name = clean_program_name(self.name or "")

        # For stack/split layers, make the default {name} template safe and useful:
        #   normal patches -> Real Patch Name
        #   layer patches  -> G4_P01 A Stack - Real Patch Name
        #   placeholder layer names -> G4_P01 A Stack
        # This prevents A/B layers from colliding when the user converts mixed folders
        # with the normal --filename-template "{name}" command.
        if self.layer_display:
            layer_prefix = f"{self.pair_display_label} {self.layer_display}".strip()
            if self.stack_split_mode_display:
                layer_prefix = f"{layer_prefix} {self.stack_split_mode_display}".strip()
            if name and not is_generic_program_name(name):
                return f"{layer_prefix} - {name}"
            return layer_prefix

        if name and not is_generic_program_name(name):
            return title_case_program_filename_name(name)
        return self.label

    @property
    def pair_display_label(self) -> str:
        return self.pair_label or self.label

    @property
    def layer_display(self) -> str:
        return self.layer or ""

    @property
    def stack_split_mode_display(self) -> str:
        return self.stack_split_mode or ""


def clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def load_possible_hex_file(path: Path) -> bytes:
    raw = path.read_bytes()
    if b"\xF0" in raw:
        return raw

    # Convenience fallback for pasted text/hex dumps.
    text = raw.decode("utf-8", errors="ignore")
    tokens = re.findall(r"\b[0-9A-Fa-f]{2}\b", text)
    if tokens and tokens[0].upper() == "F0":
        return bytes(int(t, 16) for t in tokens)
    return raw


def split_sysex_messages(data: bytes) -> List[bytes]:
    messages: List[bytes] = []
    i = 0
    while True:
        start = data.find(bytes([0xF0]), i)
        if start < 0:
            break
        end = data.find(bytes([0xF7]), start + 1)
        if end < 0:
            break
        messages.append(data[start : end + 1])
        i = end + 1
    return messages


def clean_program_name(name: str, max_len: int = 64) -> str:
    """Normalize a human patch name found in or near a SysEx message."""
    name = name.replace("\x00", " ")
    name = re.sub(r"[\x00-\x1F\x7F]+", " ", name)
    name = re.sub(r"\s+", " ", name).strip(" \t\r\n\x00-_.")

    # Some librarian formats store labels as "Name=Foo" or "Program: Foo".
    m = re.search(r"(?:name|program|patch)\s*[:=]\s*(.+)$", name, flags=re.IGNORECASE)
    if m:
        name = m.group(1).strip()

    # Trim obvious bank/location prefixes only when there is a following name.
    name = re.sub(r"^(?:[UFP]\d+|G\d+|B\d+|Bank\s*\w+|Program\s*\d+|Patch\s*\d+)\s*[-_:]+\s*", "", name, flags=re.IGNORECASE)
    name = name.strip(" \t\r\n\x00-_./")

    if len(name) > max_len:
        name = name[:max_len].rstrip()
    return name


def is_generic_program_name(name: str) -> bool:
    """Return True for placeholder/corrupt names that should not be used.

    Stack/split SysEx files can contain generic layer-program names such as
    "Basic Program" even when the paired stack/split location is the useful
    identifier. Treat these as missing names so filenames fall back to labels.
    """
    n = clean_program_name(name or "").lower()
    n = re.sub(r"\s+", " ", n).strip()
    if not n:
        return True
    if n in {"basic program", "basic programme", "init program", "init patch", "bas"}:
        return True
    if re.fullmatch(r"basic program[_\s-]*\d*", n):
        return True
    if re.fullmatch(r"g\d+[_\s-]*p\d+", n):
        return True
    if re.fullmatch(r"p\d+", n):
        return True
    return False


TITLE_CASE_ACRONYMS = {"FM", "LN", "II", "PWM", "GEO"}


def title_case_program_filename_name(name: str) -> str:
    """Title-case normal preset names for filenames while preserving key acronyms.

    This is deliberately not used for stack/split generated layer names because
    those labels are already controlled by the converter, e.g. G4_P01 A Stack.
    """
    cleaned = clean_program_name(name or "")
    if not cleaned:
        return cleaned

    def repl(match: re.Match) -> str:
        token = match.group(0)
        upper = token.upper()
        if upper in TITLE_CASE_ACRONYMS:
            return upper
        # Preserve compact synth/model-style tokens with numbers: P5, DX7, CS80.
        if any(ch.isdigit() for ch in token) and any(ch.isalpha() for ch in token):
            return upper
        # Preserve deliberate mixed-case tokens from existing banks, e.g. BassLN.
        if not token.isupper() and not token.islower() and not token.istitle():
            return token
        # Preserve attached trailing acronyms, e.g. BassLN instead of Bassln.
        if token.isupper():
            for acronym in sorted(TITLE_CASE_ACRONYMS, key=len, reverse=True):
                if upper.endswith(acronym) and len(token) > len(acronym):
                    stem = token[:-len(acronym)]
                    if stem.isalpha():
                        return stem[:1].upper() + stem[1:].lower() + acronym
        return token[:1].upper() + token[1:].lower()

    return re.sub(r"[A-Za-z0-9]+(?:'[A-Za-z0-9]+)*", repl, cleaned)


def printable_strings_from_bytes(data: bytes, min_len: int = 3, max_len: int = 64) -> List[str]:
    """Return plausible printable ASCII strings from arbitrary binary data."""
    strings: List[str] = []
    buf: List[str] = []

    def flush() -> None:
        nonlocal buf
        if not buf:
            return
        raw = "".join(buf)
        buf = []
        for part in re.split(r"\x00+", raw):
            cleaned = clean_program_name(part, max_len=max_len)
            if len(cleaned) >= min_len and re.search(r"[A-Za-z]", cleaned):
                if cleaned.startswith("#cm=") or cleaned.startswith("#AM="):
                    continue
                if len(set(cleaned)) <= 2:
                    continue
                strings.append(cleaned)

    for bval in data:
        if 32 <= bval <= 126:
            buf.append(chr(bval))
        else:
            flush()
    flush()
    return strings


def extract_name_near_payload(msg: bytes, payload_start: int, payload_end: int) -> Optional[str]:
    """Try to find a program name stored near the packed program payload.

    The official Prophet-5 Rev 4 program dump does not need a name to function,
    but several soundset/librarian files append or prepend human patch names.
    We only inspect bytes outside the 152-byte packed payload to avoid mistaking
    normal 7-bit parameter data for ASCII names.
    """
    windows = [
        msg[payload_end:-1],
        msg[max(1, payload_start - 80):payload_start],
        msg[1:payload_start] + b"\x00" + msg[payload_end:-1],
    ]
    for window in windows:
        candidates = printable_strings_from_bytes(window, min_len=3, max_len=64)
        for candidate in candidates:
            c = clean_program_name(candidate)
            if 3 <= len(c) <= 64 and not is_generic_program_name(c):
                return c
    return None


def extract_name_from_unpacked_program(unpacked: List[int]) -> Optional[str]:
    """Extract the Rev 4 stored program name when present.

    Some Prophet-5/10 Rev 4 dumps include a 20-character ASCII patch-name field
    in the unpacked program data. The hardware display may not expose it, but
    librarian/soundset files can store it. The Luke Neptune VintageClassic file
    uses bytes 65..84 for this field.
    """
    start = PROPHET_STORED_NAME_OFFSET
    end = start + PROPHET_STORED_NAME_LEN
    if len(unpacked) < end:
        return None
    raw = bytes((int(v) & 0xFF) for v in unpacked[start:end])

    # Accept printable ASCII names that may be NUL-padded. Earlier versions
    # required most of the 20-byte field to be printable, which missed short
    # names such as "Basic Program" followed by NUL padding.
    if any((bval not in (0, 32)) and not (33 <= bval <= 126) for bval in raw):
        return None

    text = raw.split(b"\x00", 1)[0].decode("ascii", errors="ignore")
    name = clean_program_name(text, max_len=PROPHET_STORED_NAME_LEN)
    if len(name) >= 3 and re.search(r"[A-Za-z]", name) and not is_generic_program_name(name):
        return name
    return None


def load_names_file(path: Optional[Path]) -> List[str]:
    if not path:
        return []
    names: List[str] = []
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        names.append(clean_program_name(line))
    return [n for n in names if n]


def unpack_dsi_packed_msbit(packed: bytes, expected_len: int = EXPECTED_UNPACKED_LEN) -> List[int]:
    """Unpack DSI/Sequential 7-bit SysEx packets.

    Each packet is 8 MIDI-safe bytes:
      byte 0: high bits for the next 7 data bytes, bit 0 -> first byte, bit 1 -> second...
      bytes 1..7: low 7 bits of the original data bytes

    Prophet-5 Rev 4 stores 128 data bytes as 19 full 8-byte packets = 152 bytes,
    padded at the end. We return only the first 128 unpacked bytes.
    """
    if len(packed) < 8:
        raise ValueError(f"Packed payload too short: {len(packed)} bytes")
    if any(b > 0x7F for b in packed):
        raise ValueError("Packed payload contains non-MIDI data bytes above 0x7F")

    out: List[int] = []
    for offset in range(0, len(packed), 8):
        packet = packed[offset : offset + 8]
        if len(packet) < 2:
            break
        header = packet[0]
        for bit_index, low7 in enumerate(packet[1:8]):
            value = (low7 & 0x7F) | (((header >> bit_index) & 0x01) << 7)
            out.append(value)

    if len(out) < expected_len:
        raise ValueError(
            f"Unpacked payload too short: got {len(out)} bytes, expected at least {expected_len}"
        )
    return out[:expected_len]


def pack_dsi_packed_msbit(data: Iterable[int]) -> bytes:
    """Pack bytes into DSI/Sequential packed MS-bit format. Used by --self-test."""
    values = list(data)
    packed = bytearray()
    for offset in range(0, len(values), 7):
        chunk = values[offset : offset + 7]
        header = 0
        lows: List[int] = []
        for i, value in enumerate(chunk):
            if value < 0 or value > 255:
                raise ValueError(f"Cannot pack out-of-range byte: {value}")
            if value & 0x80:
                header |= 1 << i
            lows.append(value & 0x7F)
        while len(lows) < 7:
            lows.append(0)
        packed.append(header)
        packed.extend(lows)
    return bytes(packed)


def plausibility_score_program_bytes(unpacked: List[int]) -> int:
    """Score whether 128 unpacked bytes look like a Prophet-5 Rev 4 program.

    This is used only by the loose parser. It is intentionally conservative:
    official messages are parsed first, and loose hits are accepted only when
    important known byte ranges make sense.
    """
    score = 0

    ranges_120 = [
        "osc_a_freq", "osc_b_freq", "osc_a_pw", "osc_b_pw", "glide_rate",
        "osc_a_level", "osc_b_level", "noise_level", "cutoff", "resonance",
        "lfo_freq", "lfo_initial_amount", "lfo_source_mix", "poly_mod_osc_b_amount",
        "filter_env_amount", "filter_attack", "amp_attack", "filter_decay",
        "amp_decay", "filter_sustain", "amp_sustain", "filter_release", "amp_release",
    ]
    bools = [
        "osc_a_saw", "osc_a_square", "osc_b_saw", "osc_b_tri", "osc_b_square",
        "osc_sync", "osc_b_low_freq", "osc_b_keyboard", "filter_rev", "lfo_saw",
        "lfo_tri", "lfo_square", "lfo_freq_a", "lfo_freq_b", "lfo_pw_a",
        "lfo_pw_b", "lfo_filter", "poly_mod_freq_a", "poly_mod_pw",
        "poly_mod_filter", "aftertouch_filter", "aftertouch_amp", "velocity_filter",
        "velocity_amp", "release_switch", "unison_on",
    ]

    for name in ranges_120:
        if 0 <= unpacked[P[name]] <= 120:
            score += 1
        else:
            score -= 5
    for name in bools:
        if unpacked[P[name]] in (0, 1):
            score += 2
        else:
            score -= 8

    if 0 <= unpacked[P["osc_b_fine"]] <= 127:
        score += 1
    if 0 <= unpacked[P["poly_mod_filter_env_amount"]] <= 127:
        score += 1
    if 0 <= unpacked[P["vintage"]] <= 127:
        score += 1
    if 0 <= unpacked[P["filter_keytrack"]] <= 2:
        score += 4
    else:
        score -= 10
    if 0 <= unpacked[P["unison_voice_count"]] <= 10:
        score += 2
    else:
        score -= 5

    # Official docs say bytes after the final saved parameter are padded with zeroes.
    # Some third-party dumps might not be perfectly clean, so this is only a bonus.
    zeros_after_54 = sum(1 for v in unpacked[54:] if v == 0)
    score += min(20, zeros_after_54 // 3)
    return score


def find_loose_program_candidates(msg: bytes, min_score: int = 75) -> List[Tuple[int, int, int, List[int]]]:
    """Find plausible 152-byte DSI packed program payloads inside any SysEx message.

    Returns tuples: (payload_start_offset_in_msg, guessed_group, guessed_program, unpacked_bytes)
    """
    candidates: List[Tuple[int, int, int, List[int]]] = []
    if len(msg) < EXPECTED_PACKED_LEN + 2:
        return candidates

    # Search inside the SysEx body, excluding F0 and F7.
    for start in range(1, len(msg) - 1 - EXPECTED_PACKED_LEN + 1):
        packed = msg[start : start + EXPECTED_PACKED_LEN]
        if any(b > 0x7F for b in packed):
            continue
        try:
            unpacked = unpack_dsi_packed_msbit(packed)
        except Exception:
            continue
        score = plausibility_score_program_bytes(unpacked)
        if score >= min_score:
            group = msg[start - 2] if start >= 2 else 0
            program = msg[start - 1] if start >= 1 else 0
            candidates.append((start, group, program, unpacked))

    # Avoid near-duplicate overlapping hits; keep earliest/highest-plausibility style by start.
    deduped: List[Tuple[int, int, int, List[int]]] = []
    used_starts: set[int] = set()
    for cand in candidates:
        start = cand[0]
        if any(abs(start - u) < 8 for u in used_starts):
            continue
        used_starts.add(start)
        deduped.append(cand)
    return deduped


def stack_split_mode_name(mode_code: int) -> str:
    # Newer Prophet-5/10 firmware uses mode values in the formerly padded
    # program bytes. Based on the observed stack/split bank, expose friendly
    # labels for filename templates and reports. If Sequential ever documents
    # the polarity differently, these two return values are the only thing
    # that need to be swapped.
    if mode_code == 2:
        return "Stack"
    if mode_code == 3:
        return "Split"
    return ""


def stack_split_link_target(unpacked: List[int]) -> Optional[Tuple[int, int, str]]:
    """Return (linked_group, linked_program, mode_name) for observed stack/split primary layers.

    Newer firmware stores layer-link metadata in bytes that were previously
    padding. In the uploaded INHALT stack/split file, primary programs use:
      byte 89 = 2 or 3, byte 91 = linked program, byte 92 = linked group.
    Secondary/layer-B programs have zeros in the same mode bytes.
    """
    if len(unpacked) <= STACK_SPLIT_LINKED_GROUP_BYTE:
        return None
    mode = unpacked[STACK_SPLIT_MODE_BYTE]
    if mode not in (2, 3):
        return None
    linked_program = unpacked[STACK_SPLIT_LINKED_PROGRAM_BYTE]
    linked_group = unpacked[STACK_SPLIT_LINKED_GROUP_BYTE]
    if not (0 <= linked_program <= 39 and 0 <= linked_group <= 9):
        return None
    return linked_group, linked_program, stack_split_mode_name(mode)


def annotate_stack_split_layers(patches: List[ProphetPatch]) -> None:
    """Mark linked stack/split program pairs as A/B layers sharing one pair label.

    This does not merge layers. It only adds filename/report metadata so RePro
    presets can be written as separate files that sort together.
    """
    by_loc: Dict[Tuple[int, int], ProphetPatch] = {}
    by_source: Dict[int, ProphetPatch] = {}
    for patch in patches:
        by_source[patch.source_index] = patch
        if patch.group is not None and patch.program is not None:
            by_loc[(patch.group, patch.program)] = patch

    for patch in patches:
        target = stack_split_link_target(patch.data)
        if not target:
            continue
        linked_group, linked_program, mode_name = target
        if patch.group == linked_group and patch.program == linked_program:
            continue

        linked = by_loc.get((linked_group, linked_program))
        # Some layer-B dumps in the wild have malformed or zeroed group/program
        # header bytes but sit immediately after the layer-A message. Use that
        # adjacency as a fallback only when the explicit target cannot be found.
        if linked is None:
            linked = by_source.get(patch.source_index + 1)
        if linked is None or linked is patch:
            continue

        pair_label = patch.label
        patch.pair_label = pair_label
        patch.layer = "A"
        patch.stack_split_mode = mode_name
        linked.pair_label = pair_label
        linked.layer = "B"
        linked.stack_split_mode = mode_name


def location_sort_key(label: str) -> Tuple[int, int, str]:
    m = re.match(r"G(\d+)_P(\d+)", label)
    if m:
        return int(m.group(1)), int(m.group(2)), label
    return 9999, 9999, label


def sort_stack_split_pairs(patches: List[ProphetPatch]) -> None:
    if not any(p.pair_label for p in patches):
        return
    layer_order = {"A": 0, "B": 1}
    patches.sort(key=lambda p: (
        location_sort_key(p.pair_display_label),
        layer_order.get(p.layer_display, 2),
        p.source_index,
    ))


def parse_prophet_patches(path: Path, loose_fallback: bool = True) -> List[ProphetPatch]:
    data = load_possible_hex_file(path)
    messages = split_sysex_messages(data)
    patches: List[ProphetPatch] = []

    for idx, msg in enumerate(messages, start=1):
        if len(msg) < 6:
            continue
        if msg[0] != 0xF0 or msg[-1] != 0xF7:
            continue
        if msg[1] != DSI_ID or msg[2] not in PROPHET5_IDS:
            continue

        command = msg[3]
        if command == PROGRAM_DUMP:
            if len(msg) < 6 + EXPECTED_PACKED_LEN + 1:
                print(
                    f"Warning: skipping short program dump in {path.name}: {len(msg)} bytes",
                    file=sys.stderr,
                )
                continue
            group = msg[4]
            program = msg[5]
            payload_start = 6
            payload_end = 6 + EXPECTED_PACKED_LEN
            packed = msg[payload_start:payload_end]
            trailing = len(msg) - (payload_end + 1)
            name = extract_name_near_payload(msg, payload_start, payload_end)
            if trailing and not name:
                print(
                    f"Note: program dump {idx} has {trailing} extra byte(s) after the 152-byte payload; no readable name found there.",
                    file=sys.stderr,
                )
            unpacked = unpack_dsi_packed_msbit(packed)
            name = extract_name_from_unpacked_program(unpacked) or name
            patches.append(ProphetPatch(idx, "program", group, program, unpacked, name))

        elif command == EDIT_BUFFER_DUMP:
            if len(msg) < 4 + EXPECTED_PACKED_LEN + 1:
                print(
                    f"Warning: skipping short edit-buffer dump in {path.name}: {len(msg)} bytes",
                    file=sys.stderr,
                )
                continue
            payload_start = 4
            payload_end = 4 + EXPECTED_PACKED_LEN
            packed = msg[payload_start:payload_end]
            trailing = len(msg) - (payload_end + 1)
            name = extract_name_near_payload(msg, payload_start, payload_end)
            if trailing and not name:
                print(
                    f"Note: edit-buffer dump {idx} has {trailing} extra byte(s) after the 152-byte payload; no readable name found there.",
                    file=sys.stderr,
                )
            unpacked = unpack_dsi_packed_msbit(packed)
            name = extract_name_from_unpacked_program(unpacked) or name
            patches.append(ProphetPatch(idx, "edit_buffer", None, None, unpacked, name))

    if patches or not loose_fallback:
        # If official program dumps were found, still add any plausible
        # malformed stack/split layer dumps that were not official command 0x02.
        for idx, msg in enumerate(messages, start=1):
            if not (len(msg) >= 6 + EXPECTED_PACKED_LEN + 1 and msg[0] == 0xF0 and msg[-1] == 0xF7):
                continue
            if msg[1] != DSI_ID or msg[2] not in PROPHET5_IDS or msg[3] in (PROGRAM_DUMP, EDIT_BUFFER_DUMP):
                continue
            try:
                unpacked = unpack_dsi_packed_msbit(msg[6:6 + EXPECTED_PACKED_LEN])
            except Exception:
                continue
            if plausibility_score_program_bytes(unpacked) < 75:
                continue
            group = msg[4]
            program = msg[5]
            name = extract_name_from_unpacked_program(unpacked) or extract_name_near_payload(msg, 6, 6 + EXPECTED_PACKED_LEN)
            patches.append(ProphetPatch(idx, "program_loose_extra", group, program, unpacked, name))
        annotate_stack_split_layers(patches)
        sort_stack_split_pairs(patches)
        return patches

    # Loose fallback for third-party soundsets with unexpected framing.
    # It searches for any plausible 152-byte packed Prophet program payload inside SysEx messages.
    seen: set[Tuple[int, Tuple[int, ...]]] = set()
    for idx, msg in enumerate(messages, start=1):
        for candidate_num, (start, group, program, unpacked) in enumerate(find_loose_program_candidates(msg), start=1):
            key = (idx, tuple(unpacked[:54]))
            if key in seen:
                continue
            seen.add(key)
            name = extract_name_from_unpacked_program(unpacked) or extract_name_near_payload(msg, start, start + EXPECTED_PACKED_LEN)
            print(
                f"Loose parser: found plausible Prophet program payload in message {idx} at byte offset {start}." + (f" Name: {name}" if name else ""),
                file=sys.stderr,
            )
            patches.append(ProphetPatch(idx * 1000 + candidate_num, "program_loose", group, program, unpacked, name))

    annotate_stack_split_layers(patches)
    sort_stack_split_pairs(patches)
    return patches


def scan_sysex_file(path: Path) -> int:
    data = load_possible_hex_file(path)
    messages = split_sysex_messages(data)
    print(f"File: {path}")
    print(f"Bytes: {len(data)}")
    print(f"SysEx messages found: {len(messages)}")
    if not messages:
        print("No F0...F7 SysEx messages were found. The file may be wrapped, corrupt, or not a raw .syx file.")
        return 1

    for idx, msg in enumerate(messages, start=1):
        body_len = len(msg) - 2
        header = " ".join(f"{b:02X}" for b in msg[:min(len(msg), 12)])
        print(f"\nMessage {idx}: total={len(msg)} bytes, body={body_len} bytes")
        print(f"  First bytes: {header}{' ...' if len(msg) > 12 else ''}")
        if len(msg) >= 4:
            print(f"  IDs/command guess: {msg[1]:02X} {msg[2]:02X} {msg[3]:02X}")
        if len(msg) >= 7 and msg[1] == DSI_ID and msg[2] in PROPHET5_IDS and msg[3] == PROGRAM_DUMP:
            print(f"  Official Prophet-5 program dump candidate: group={msg[4]}, program={msg[5]}, packed_len={len(msg[6:-1])}")
            try:
                unpacked = unpack_dsi_packed_msbit(msg[6:6 + EXPECTED_PACKED_LEN])
                stored_name = extract_name_from_unpacked_program(unpacked)
            except Exception:
                stored_name = None
            n = stored_name or extract_name_near_payload(msg, 6, 6 + EXPECTED_PACKED_LEN)
            if n:
                print(f"  Embedded name candidate: {n}")
        elif len(msg) >= 5 and msg[1] == DSI_ID and msg[2] in PROPHET5_IDS and msg[3] == EDIT_BUFFER_DUMP:
            print(f"  Official Prophet-5 edit-buffer dump candidate: packed_len={len(msg[4:-1])}")
            try:
                unpacked = unpack_dsi_packed_msbit(msg[4:4 + EXPECTED_PACKED_LEN])
                stored_name = extract_name_from_unpacked_program(unpacked)
            except Exception:
                stored_name = None
            n = stored_name or extract_name_near_payload(msg, 4, 4 + EXPECTED_PACKED_LEN)
            if n:
                print(f"  Embedded name candidate: {n}")
        loose = find_loose_program_candidates(msg)
        if loose:
            for start, group, program, unpacked in loose[:5]:
                score = plausibility_score_program_bytes(unpacked)
                n = extract_name_from_unpacked_program(unpacked) or extract_name_near_payload(msg, start, start + EXPECTED_PACKED_LEN)
                print(f"  Loose candidate: payload_offset={start}, guessed_group={group}, guessed_program={program}, score={score}" + (f", name={n}" if n else ""))
        else:
            print("  No loose Prophet-program payload candidate found in this message.")
    return 0


class H2PTemplate:
    def __init__(self, text: str):
        self.lines = text.splitlines()

    def clone(self) -> "H2PTemplate":
        new = H2PTemplate("")
        new.lines = list(self.lines)
        return new

    def _section_bounds(self, section: str) -> Tuple[int, int]:
        marker = f"#cm={section}"
        start = -1
        for i, line in enumerate(self.lines):
            if line.strip() == marker:
                start = i
                break
        if start < 0:
            raise KeyError(f"Missing #cm={section} section in template")

        end = len(self.lines)
        for j in range(start + 1, len(self.lines)):
            if self.lines[j].startswith("#cm="):
                end = j
                break
        return start, end

    def set(self, section: str, key: str, value: Any, decimals: int = 2) -> None:
        start, end = self._section_bounds(section)
        prefix = f"{key}="
        if isinstance(value, bool):
            rendered = "1" if value else "0"
        elif isinstance(value, int):
            rendered = str(value)
        elif isinstance(value, float):
            rendered = f"{value:.{decimals}f}"
        else:
            rendered = str(value)

        new_line = f"{key}={rendered}"
        for i in range(start + 1, end):
            if self.lines[i].startswith(prefix):
                self.lines[i] = new_line
                return

        # If the key is not present, insert it before the next section marker.
        self.lines.insert(end, new_line)

    def text(self) -> str:
        return "\n".join(self.lines) + "\n"


def default_profile() -> Dict[str, Any]:
    return {
        "metadata": {
            "name": "p5rev4_to_repro5_default_1_0",
            "version": "2.9",
            "notes": "First-pass Prophet-5 Rev 4 to RePro-5 mapping. Tune transforms after listening tests. v3.1 normalizes oscillator boundary mappings so B+/one-raw-unit-below-octave values become the next octave with Freq 0 when available; v2.9 adds extra smart-output padding when resonance is above halfway; v2.8 adds smart per-patch output scoring with 25.00-50.00 bounds; v2.7 raised unison-aware output level from 20.00 to 33.00; v2.1 restores full-range Poly/Voice Mod filter-envelope amount mapping; v1.9 adds stack/split layer pairing fields for breakout conversion; v1.8 corrects non-Poly high-cutoff overshoot after patch self-resonance testing; v1.7 adds unison-aware output levels, scales glide down, and scales Poly/Voice Mod filter-envelope amount down to match Osc B voice mod; v1.6 made Prophet Initial LFO Amount -> RePro GMod.LowLim even more subtle and scaled Poly/Voice Mod Osc B amount down considerably; v1.5 made Initial Amount mapping more subtle; v1.4 uses per-sysex folders for --all-syx; v1.3 sets RePro final output CcOp to 40.00 by default; v1.2 updates filter cutoff compensation using resonance-only hardware/RePro measurements and adds --all-syx folder conversion support; v1.1 maps Prophet Unison On to RePro Voice.Logic and maps voice count only on unison patches; v1.0 maps aftertouch into reserved MM1/MM2 matrix slots, v0.9 quantizes oscillator coarse frequency to whole semitones by default, and v0.5 maps Prophet Osc B Fine unipolar-positive to RePro OscB.Fine 0.00 to +20.00.",
        },
        "global_output": {
            "enabled": True,
            "section": "main",
            "key": "CcOp",
            "value": 40.0,
            "poly_value": 50.0,
            "unison_value": 33.0,
            "mode": "smart_patch",
            "smart_output": {
                "poly_lower_bound": 25.0,
                "poly_upper_bound": 50.0,
                "unison_lower_bound": 25.0,
                "unison_upper_bound": 50.0,
                "mixer_hot_start_ratio": 0.62,
                "poly_mixer_pad_max": 5.0,
                "unison_mixer_pad_max": 5.0,
                "filter_env_open_weight": 0.55,
                "slow_filter_attack_reduction": 0.60,
                "filter_open_start_raw": 62.0,
                "filter_open_full_raw": 127.0,
                "poly_filter_pad_max": 10.0,
                "unison_filter_pad_max": 8.0,
                "resonance_pad_start_raw": 60.0,
                "resonance_pad_full_raw": 120.0,
                "poly_resonance_pad_max": 5.0,
                "unison_resonance_pad_max": 5.0,
                "poly_combo_pad_max": 8.0,
                "unison_combo_pad_max": 4.0,
                "poly_amp_body_pad_max": 4.0,
                "unison_amp_body_pad_max": 2.5,
                "unison_voice_count_pad_per_extra_voice": 2.5,
                "sync_pad": 6.0,
                "note": "v2.9 adds resonance padding above halfway. v2.8 estimates patch loudness from A/B mixer level, filter openness including Env Depth, amp body/sustain, sync, and unison voice count. Output is clamped to 25.00-50.00."
            },
            "note": "v2.9 RePro-5 final output uses smart per-patch scoring with extra high-resonance padding."
        },
        "filter_revision_values": {"0": "rev_1_2", "1": "rev_3"},
        "filter_revision_mapping": {"rev_1_2": "driven", "rev_3": "poly"},
        "repro_filter_chips": {"crispy": 0, "rounded": 1, "driven": 2, "poly": 3},
        "repro_oscillator_chips": {
            "enabled": True,
            "when_filter_mapping": {
                "rev_1_2": {"driven": 3}
            },
            "note": "Final 1.0: when Prophet Rev 1/2 is mapped to RePro Driven, use RePro's P5 Old oscillator tweak on OscAIC/OscBIC (Chip=3)."
        },
        "transforms": {
            "scale_120_to_100": {"type": "linear", "in_min": 0, "in_max": 120, "out_min": 0, "out_max": 100},
            "scale_127_to_100": {"type": "linear", "in_min": 0, "in_max": 127, "out_min": 0, "out_max": 100},
            "osc_b_fine_positive": {"type": "linear", "in_min": 0, "in_max": 127, "out_min": 0, "out_max": 20},
            "fine_127_to_pm50": {"type": "piecewise", "points": [[0, -50], [64, 0], [127, 50]]},
            "vintage_to_detune": {"type": "linear", "in_min": 0, "in_max": 127, "out_min": 22, "out_max": 45},
            "cutoff": {"type": "linear", "in_min": 0, "in_max": 120, "out_min": 0, "out_max": 100},
            "cutoff_rev_1_2_crispy": {"type": "piecewise", "points": [[0.0, 0.0], [12.0, 0.0], [24.0, 0.0], [36.0, 8.45], [48.0, 23.12], [60.0, 33.63], [72.0, 49.65], [84.0, 60.48], [96.0, 72.35], [108.0, 79.8], [120.0, 79.1]], "note": "v1.2 resonance-only cutoff compensation: maps Hardware Rev 1/2 cutoff frequency to RePro Crispy cutoff value."},
            "cutoff_rev_1_2_driven": {"type": "piecewise", "points": [[0.0, 0.0], [12.0, 0.0], [24.0, 0.27], [36.0, 12.41], [48.0, 27.48], [60.0, 38.01], [72.0, 52.89], [84.0, 63.76], [96.0, 76.26], [108.0, 83.08], [120.0, 84.0]], "note": "v1.2 resonance-only cutoff compensation: maps Hardware Rev 1/2 cutoff frequency to RePro Driven cutoff value."},
            "cutoff_rev_1_2_poly": {"type": "piecewise", "points": [[0.0, 0.0], [12.0, 0.0], [24.0, 14.82], [36.0, 28.66], [48.0, 43.19], [60.0, 53.85], [72.0, 69.82], [84.0, 80.48], [96.0, 92.35], [108.0, 99.8], [120.0, 100.0]], "note": "v1.2 resonance-only cutoff compensation: maps Hardware Rev 1/2 cutoff frequency to RePro Poly cutoff value."},
            "cutoff_rev_1_2_rounded": {"type": "piecewise", "points": [[0.0, 0.0], [12.0, 0.0], [24.0, 1.14], [36.0, 12.5], [48.0, 26.24], [60.0, 35.85], [72.0, 50.42], [84.0, 60.51], [96.0, 71.48], [108.0, 77.57], [120.0, 77.5]], "note": "v1.2 resonance-only cutoff compensation: maps Hardware Rev 1/2 cutoff frequency to RePro Rounded cutoff value."},
            "cutoff_rev_3_crispy": {"type": "piecewise", "points": [[0.0, 0.0], [12.0, 0.0], [24.0, 0.0], [36.0, 8.01], [48.0, 22.99], [60.0, 33.08], [72.0, 49.29], [84.0, 59.21], [96.0, 71.86], [108.0, 78.6], [120.0, 79.1]], "note": "v1.2 resonance-only cutoff compensation: maps Hardware Rev 3 cutoff frequency to RePro Crispy cutoff value."},
            "cutoff_rev_3_driven": {"type": "piecewise", "points": [[0.0, 0.0], [12.0, 0.0], [24.0, 0.16], [36.0, 12.13], [48.0, 27.3], [60.0, 37.29], [72.0, 52.66], [84.0, 62.59], [96.0, 75.61], [108.0, 82.27], [120.0, 84.0]], "note": "v1.2 resonance-only cutoff compensation: maps Hardware Rev 3 cutoff frequency to RePro Driven cutoff value."},
            "cutoff_rev_3_poly": {"type": "piecewise", "points": [[0.0, 0.0], [12.0, 0.0], [24.0, 14.67], [36.0, 28.19], [48.0, 43.05], [60.0, 53.29], [72.0, 69.47], [84.0, 79.22], [96.0, 91.86], [108.0, 98.6], [120.0, 100.0]], "note": "v1.2 resonance-only cutoff compensation: maps Hardware Rev 3 cutoff frequency to RePro Poly cutoff value."},
            "cutoff_rev_3_rounded": {"type": "piecewise", "points": [[0.0, 0.0], [12.0, 0.0], [24.0, 1.02], [36.0, 12.25], [48.0, 26.08], [60.0, 35.26], [72.0, 50.25], [84.0, 59.41], [96.0, 71.07], [108.0, 76.59], [120.0, 77.5]], "note": "v1.2 resonance-only cutoff compensation: maps Hardware Rev 3 cutoff frequency to RePro Rounded cutoff value."},
            "cutoff_crispy": {"type": "piecewise", "points": [[0.0, 0.0], [12.0, 0.0], [24.0, 0.0], [36.0, 8.45], [48.0, 23.12], [60.0, 33.63], [72.0, 49.65], [84.0, 60.48], [96.0, 72.35], [108.0, 79.8], [120.0, 79.1]], "note": "Compatibility alias for rev_1_2 -> crispy."},
            "cutoff_rounded": {"type": "piecewise", "points": [[0.0, 0.0], [12.0, 0.0], [24.0, 1.14], [36.0, 12.5], [48.0, 26.24], [60.0, 35.85], [72.0, 50.42], [84.0, 60.51], [96.0, 71.48], [108.0, 77.57], [120.0, 77.5]], "note": "Compatibility alias for rev_1_2 -> rounded."},
            "cutoff_driven": {"type": "piecewise", "points": [[0.0, 0.0], [12.0, 0.0], [24.0, 0.27], [36.0, 12.41], [48.0, 27.48], [60.0, 38.01], [72.0, 52.89], [84.0, 63.76], [96.0, 76.26], [108.0, 83.08], [120.0, 84.0]], "note": "Compatibility alias for rev_1_2 -> driven."},
            "cutoff_poly": {"type": "piecewise", "points": [[0.0, 0.0], [12.0, 0.0], [24.0, 14.67], [36.0, 28.19], [48.0, 43.05], [60.0, 53.29], [72.0, 69.47], [84.0, 79.22], [96.0, 91.86], [108.0, 98.6], [120.0, 100.0]], "note": "Compatibility alias for rev_3 -> poly."},
            "resonance": {"type": "linear", "in_min": 0, "in_max": 120, "out_min": 0, "out_max": 100},
            "filter_env_amount": {"type": "linear", "in_min": 0, "in_max": 120, "out_min": 0, "out_max": 100},
            "env_attack": {"type": "piecewise", "points": [[0, 0.0], [12, 10.0], [24, 20.0], [36, 32.0], [48, 43.16], [60, 52.41], [72, 65.86], [84, 80.11], [96, 84.57], [108, 95.41], [120, 99.95]], "note": "v2.4 envelope calibration from measured 10-90 attack timings."},
            "env_decay": {"type": "piecewise", "points": [[0, 0.0], [12, 20.0], [24, 30.0], [36, 32.86], [48, 41.62], [60, 51.40], [72, 63.51], [84, 78.70], [96, 84.18], [108, 95.10], [120, 100.0]], "note": "v2.4 envelope calibration from measured peak-to-50%-sustain decay timings."},
            "env_sustain": {"type": "linear", "in_min": 0, "in_max": 120, "out_min": 0, "out_max": 100},
            "env_release": {"type": "piecewise", "points": [[0, 10.0], [12, 10.0], [24, 12.5], [36, 28.0], [48, 35.23], [60, 45.05], [72, 58.24], [84, 71.97], [96, 78.51], [108, 89.61], [120, 92.32]], "note": "v2.4 envelope calibration from measured release 90-10 timings."},
            "lfo_freq": {"type": "linear", "in_min": 0, "in_max": 120, "out_min": 0, "out_max": 100},
            "lfo_amount": {"type": "piecewise", "points": [[0, 0], [14, 0.5], [38, 11], [60, 18], [90, 32], [120, 45]], "note": "v1.6 extra-conservative Prophet Initial Amount -> RePro GMod.LowLim. Raw 14 maps to 0.50; raw 38 still maps around 11.00 based on listening note."},
            "poly_mod_osc_b_amount": {"type": "piecewise", "points": [[0, 0.0], [18.0, 7.37], [23.0, 14.89], [36.5, 29.30], [58.0, 51.35], [100.5, 88.00], [120.0, 100.00]], "note": "v2.5 measured Osc B Voice Mod pitch-depth curve from Prophet/RePro interval matching. Replaces the v1.6 reduced 0-36 mapping."},
            "poly_mod_filter_env_amount": {"type": "linear", "in_min": 0, "in_max": 127, "out_min": 0, "out_max": 100, "note": "v2.7 raises unison-aware output level from 20.00 to 33.00; v2.1 restores full-range Prophet Poly/Voice Mod filter-envelope source amount mapping. Raw max maps to RePro max."},
            "glide_rate_subtle": {"type": "linear", "in_min": 0, "in_max": 120, "out_min": 0, "out_max": 40, "note": "v1.7 scales RePro glide down because RePro glide times are much longer. Raw value that previously mapped near 60 now lands near 20."},
        },
        "parameter_transforms": {
            "osc_b_fine": "osc_b_fine_positive",
            "osc_a_pw": "scale_120_to_100",
            "osc_b_pw": "scale_120_to_100",
            "glide_rate": "glide_rate_subtle",
            "osc_a_level": "scale_120_to_100",
            "osc_b_level": "scale_120_to_100",
            "noise_level": "scale_120_to_100",
            "cutoff": "cutoff",
            "resonance": "resonance",
            "filter_env_amount": "filter_env_amount",
            "filter_attack": "env_attack",
            "amp_attack": "env_attack",
            "filter_decay": "env_decay",
            "amp_decay": "env_decay",
            "filter_sustain": "env_sustain",
            "amp_sustain": "env_sustain",
            "filter_release": "env_release",
            "amp_release": "env_release",
            "lfo_freq": "lfo_freq",
            "lfo_initial_amount": "lfo_amount",
            "lfo_source_mix": "scale_120_to_100",
            "poly_mod_osc_b_amount": "poly_mod_osc_b_amount",
            "poly_mod_filter_env_amount": "poly_mod_filter_env_amount",
            "vintage": "vintage_to_detune",
        },
        "filter_keytrack_values": {"0": 0.0, "1": 37.5, "2": 75.0},
        "velocity_on_value": {"filter": 25.0, "amp": 25.0},
        "unison": {
            "enabled": True,
            "logic_off": 0,
            "logic_on": 1,
            "poly_nvoices": 8,
            "unison_default_nvoices": 8,
            "unison_min_nvoices": 1,
            "unison_max_nvoices": 8,
            "zero_or_blank_means_default": True,
            "note": "If Prophet Unison On is set, RePro Voice.Logic=1 and NVoices follows the Prophet voice-count byte, clamped to RePro's range. Raw 0 uses unison_default_nvoices. Non-unison patches remain polyphonic and keep/set NVoices to poly_nvoices."
        },
        "aftertouch": {
            "enabled": True,
            "source": 11,
            "filter_slot": "MM1",
            "filter_destination": "Filter:Cutoff",
            "filter_depth_when_on": 50.0,
            "lfo_slot": "MM2",
            "lfo_destination": "GMod:LowLim",
            "lfo_depth_when_on": 50.0,
            "curve": 2,
            "note": "Reserved RePro-5 matrix slots for Prophet aftertouch. Source 11 = Pressure. Slot depths are 0 unless the Prophet patch enables aftertouch-to-filter or aftertouch-to-LFO-depth."
        },
        "release_switch_off": "zero_releases",
        "osc_frequency": {
            "enabled": True,
            "mode": "prophet_raw_24_units_per_octave_repro_centered",
            "units_per_octave": 24,
            "units_per_semitone": 2,
            "semitone_quantize": "floor",
            "round_up_octave_boundary_minus_one": True,
            "normalize_plus_12_to_next_octave": True,
            "prophet_raw_max": 120,
            "repro_oct_min": 0,
            "repro_oct_max": 3,
            "repro_global_semitone_offset": -12,
            "note": "Prophet raw oscillator frequency spans C0..C4 across raw 0..120. RePro has Oct 0..3 plus bipolar Freq -12..+12, so raw 0 maps to Oct=0/Freq=-12, raw 24 maps to Oct=0/Freq=0, raw 48 maps to Oct=1/Freq=0, raw 96 maps to Oct=3/Freq=0, and raw 120 maps to Oct=3/Freq=+12. Odd raw values are quantized down by default, except raw values one unit below the next C boundary, such as raw 23/B0+, are rounded up because tested patches behave musically like the upper boundary.",
        },
        "experimental": {
            "map_lfo_destinations": True,
            "map_lfo_initial_amount_to_gmod_lowlim": True,
            "map_poly_mod": True,
            "map_unison": True,
            "map_aftertouch": True,
        },
        "ignored_parameters": [],
    }


def merge_profile(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    result = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = merge_profile(result[key], value)
        else:
            result[key] = value
    return result


def load_profile(path: Optional[Path]) -> Dict[str, Any]:
    profile = default_profile()
    if path:
        override = json.loads(path.read_text(encoding="utf-8"))
        profile = merge_profile(profile, override)
    return profile


def apply_transform(value: float, transform: Dict[str, Any]) -> float:
    t = transform.get("type", "linear")

    if t == "linear":
        in_min = float(transform.get("in_min", 0))
        in_max = float(transform.get("in_max", 1))
        out_min = float(transform.get("out_min", 0))
        out_max = float(transform.get("out_max", 1))
        if in_max == in_min:
            return out_min
        n = (value - in_min) / (in_max - in_min)
        n = clamp(n, 0.0, 1.0)
        return out_min + n * (out_max - out_min)

    if t == "gamma":
        in_min = float(transform.get("in_min", 0))
        in_max = float(transform.get("in_max", 1))
        out_min = float(transform.get("out_min", 0))
        out_max = float(transform.get("out_max", 1))
        gamma = float(transform.get("gamma", 1.0))
        if in_max == in_min:
            return out_min
        n = clamp((value - in_min) / (in_max - in_min), 0.0, 1.0)
        n = math.pow(n, gamma)
        return out_min + n * (out_max - out_min)

    if t == "piecewise":
        points = [(float(a), float(b)) for a, b in transform.get("points", [])]
        if not points:
            return value
        points.sort(key=lambda p: p[0])
        if value <= points[0][0]:
            return points[0][1]
        if value >= points[-1][0]:
            return points[-1][1]
        for (x0, y0), (x1, y1) in zip(points, points[1:]):
            if x0 <= value <= x1:
                if x1 == x0:
                    return y0
                n = (value - x0) / (x1 - x0)
                return y0 + n * (y1 - y0)
        return points[-1][1]

    if t == "lookup":
        table = transform.get("values", {})
        return float(table.get(str(int(value)), value))

    raise ValueError(f"Unknown transform type: {t}")


def xform(profile: Dict[str, Any], param_name: str, raw: float) -> float:
    transform_name = profile.get("parameter_transforms", {}).get(param_name, "scale_120_to_100")
    return xform_transform(profile, transform_name, raw, param_name)


def xform_transform(profile: Dict[str, Any], transform_name: str, raw: float, param_name: str = "") -> float:
    transform = profile.get("transforms", {}).get(transform_name)
    if transform is None:
        label = f" for {param_name}" if param_name else ""
        raise KeyError(f"Missing transform '{transform_name}'{label}")
    return clamp(apply_transform(raw, transform), -100.0, 100.0)


def b(value: int) -> int:
    return 1 if int(value) else 0


def set_and_report(h2p: H2PTemplate, report: List[Dict[str, Any]], section: str, key: str, value: Any,
                   prophet_param: str = "", raw: Any = "", note: str = "") -> None:
    h2p.set(section, key, value)
    report.append(
        {
            "prophet_parameter": prophet_param,
            "raw_value": raw,
            "repro_section": section,
            "repro_key": key,
            "repro_value": value,
            "note": note,
        }
    )



def prophet_freq_to_repro_oct_freq(raw: int, profile: Dict[str, Any]) -> Tuple[int, float]:
    """Map Prophet Rev 4 oscillator coarse frequency to RePro-5 Oct/Freq.

    Prophet Rev 4 oscillator frequency spans roughly C0..C4 across raw 0..120.
    RePro-5 represents a similar musical span using Oct 0..3 plus bipolar
    Freq -12..+12. The practical mapping is therefore centered one octave lower
    than the earlier converter builds:

      raw 0   -> RePro Oct=0, Freq=-12
      raw 24  -> RePro Oct=0, Freq=0
      raw 48  -> RePro Oct=1, Freq=0
      raw 72  -> RePro Oct=2, Freq=0
      raw 96  -> RePro Oct=3, Freq=0
      raw 120 -> RePro Oct=3, Freq=+12

    Odd raw values are normally floored to the lower semitone. Exception:
    one-unit-before-C boundary values like raw 23/B0+ are rounded up to the
    next C because tested hardware patches behave musically that way.
    """
    cfg = profile.get("osc_frequency", {})
    units_per_octave = int(cfg.get("units_per_octave", 24))
    units_per_semitone = float(cfg.get("units_per_semitone", 2))
    oct_min = int(cfg.get("repro_oct_min", 0))
    oct_max = int(cfg.get("repro_oct_max", 3))
    global_offset = float(cfg.get("repro_global_semitone_offset", -12.0))
    raw_max = cfg.get("prophet_raw_max", 120)

    raw = int(raw)
    if raw_max is not None:
        raw = min(raw, int(raw_max))
    raw = max(raw, 0)

    octave_raw = raw // units_per_octave
    remainder = raw - octave_raw * units_per_octave
    prophet_semitones = raw / units_per_semitone

    quantize_mode = str(cfg.get("semitone_quantize", "floor")).lower()
    if quantize_mode in ("floor", "down", "truncate", "true", "1", "yes"):
        prophet_semitones = math.floor(prophet_semitones + 1e-9)

        # Sequential's Rev 4 UI can show values like B0+ where the raw coarse
        # byte is one unit below the next C boundary. In tested factory patches
        # this behaves musically closer to the upper C/octave boundary. Keep the
        # existing floor behavior for values just above C, e.g. raw 25 -> C1,
        # but let raw 23/47/71/etc. reach the upper C boundary instead of +11.
        if cfg.get("round_up_octave_boundary_minus_one", True):
            if remainder == units_per_octave - 1:
                prophet_semitones += 1.0
    elif quantize_mode in ("round", "nearest"):
        prophet_semitones = math.floor(prophet_semitones + 0.5)
    elif quantize_mode in ("none", "off", "false", "0", "no"):
        pass
    else:
        raise ValueError(f"Unknown osc_frequency.semitone_quantize mode: {quantize_mode}")

    # Shift into RePro's centered Oct/Freq representation.
    total = prophet_semitones + global_offset

    if total < oct_min * 12:
        octave = oct_min
        semitones = total - octave * 12
    elif total > oct_max * 12:
        octave = oct_max
        semitones = total - octave * 12
    else:
        octave = int(math.floor(total / 12.0 + 1e-9))
        semitones = total - octave * 12

    # Clean up exact +12 boundaries into the next octave when possible. The top
    # boundary remains Oct max / Freq +12 because RePro has no next octave there.
    if cfg.get("normalize_plus_12_to_next_octave", True):
        if semitones >= 12.0 and octave < oct_max:
            octave += 1
            semitones = 0.0
        elif semitones <= -12.0 and octave > oct_min:
            octave -= 1
            semitones = 0.0

    octave = int(clamp(octave, oct_min, oct_max))
    semitones = clamp(semitones, -12.0, 12.0)
    return octave, semitones


def apply_aftertouch_matrix(h2p: H2PTemplate, report: List[Dict[str, Any]], profile: Dict[str, Any], d: List[int]) -> None:
    """Reserve RePro-5 MM1/MM2 for Prophet Rev 4 aftertouch behavior.

    Prophet Rev 4 exposes aftertouch destination switches rather than continuous
    depths in the stored program data. RePro-5 can approximate those switches by
    assigning Pressure to fixed mod-matrix destinations and setting the slot
    depth only when the Prophet flag is on.

    MM1: Pressure -> Filter:Cutoff
    MM2: Pressure -> GMod:LowLim, which raises the base/global LFO amount.
    """
    cfg = profile.get("aftertouch", {})
    enabled = bool(cfg.get("enabled", True)) and bool(profile.get("experimental", {}).get("map_aftertouch", True))

    source = int(cfg.get("source", 11))  # RePro-5 Source=11 is Pressure.
    curve = int(cfg.get("curve", 2))

    filter_slot = str(cfg.get("filter_slot", "MM1"))
    filter_dest = str(cfg.get("filter_destination", "Filter:Cutoff"))
    filter_depth = float(cfg.get("filter_depth_when_on", 50.0)) if enabled and int(d[P["aftertouch_filter"]]) else 0.0

    lfo_slot = str(cfg.get("lfo_slot", "MM2"))
    lfo_dest = str(cfg.get("lfo_destination", "GMod:LowLim"))
    lfo_depth = float(cfg.get("lfo_depth_when_on", 50.0)) if enabled and int(d[P["aftertouch_amp"]]) else 0.0

    for slot, dest, depth, prophet_param, raw, note in [
        (filter_slot, filter_dest, filter_depth, "aftertouch_filter", d[P["aftertouch_filter"]], "reserved MM slot: Pressure -> Filter Cutoff; depth set when Prophet AT->Filter is on"),
        (lfo_slot, lfo_dest, lfo_depth, "aftertouch_lfo_amount", d[P["aftertouch_amp"]], "reserved MM slot: Pressure -> GMod LowLim / LFO amount floor; depth set when Prophet AT->LFO amount is on"),
    ]:
        set_and_report(h2p, report, slot, "Source", source, prophet_param, raw, note)
        set_and_report(h2p, report, slot, "Dest1", dest, prophet_param, raw, note)
        set_and_report(h2p, report, slot, "Depth1", depth, prophet_param, raw, note)
        set_and_report(h2p, report, slot, "Curve1", curve, prophet_param, raw, note)
        set_and_report(h2p, report, slot, "Qntze1", 0, prophet_param, raw, note)
        set_and_report(h2p, report, slot, "Rect1", 0, prophet_param, raw, note)
        set_and_report(h2p, report, slot, "SH1", 0, prophet_param, raw, note)
        set_and_report(h2p, report, slot, "Slew1", 0, prophet_param, raw, note)


def prophet_unison_voice_count_to_repro(raw_count: int, profile: Dict[str, Any]) -> int:
    cfg = profile.get("unison", {})
    default_nvoices = int(cfg.get("unison_default_nvoices", 8))
    min_nvoices = int(cfg.get("unison_min_nvoices", 1))
    max_nvoices = int(cfg.get("unison_max_nvoices", 8))
    raw_count = int(raw_count)

    if raw_count <= 0 and bool(cfg.get("zero_or_blank_means_default", True)):
        return int(clamp(default_nvoices, min_nvoices, max_nvoices))

    return int(clamp(raw_count, min_nvoices, max_nvoices))


def ramp01(value: float, start: float, end: float) -> float:
    """0..1 ramp with clamping, used by smart output scoring."""
    if end <= start:
        return 1.0 if value >= end else 0.0
    return clamp((value - start) / (end - start), 0.0, 1.0)


def calculate_smart_patch_output(profile: Dict[str, Any], d: List[int]) -> Tuple[float, str]:
    """Estimate a sensible RePro final output level for each converted patch.

    This is intentionally a conservative heuristic, not a real loudness model.
    It starts from an upper output level and subtracts padding for the factors
    that have been making converted patches jump out: high A/B mixer levels,
    very open filter behavior once cutoff and filter envelope are considered,
    oscillator sync, and unison voice stacking.
    """
    output_cfg = profile.get("global_output", {})
    smart = output_cfg.get("smart_output", {})

    unison_on = int(d[P["unison_on"]]) != 0
    prefix = "unison" if unison_on else "poly"
    lower = float(smart.get(f"{prefix}_lower_bound", smart.get("lower_bound", 25.0)))
    upper = float(smart.get(f"{prefix}_upper_bound", smart.get("upper_bound", 50.0)))
    if lower > upper:
        lower, upper = upper, lower

    # Raw mixer values can be 120 or 127 depending on dump/source. Treat 127 as max.
    osc_a_ratio = clamp(float(d[P["osc_a_level"]]) / 127.0, 0.0, 1.0)
    osc_b_ratio = clamp(float(d[P["osc_b_level"]]) / 127.0, 0.0, 1.0)
    noise_ratio = clamp(float(d[P["noise_level"]]) / 127.0, 0.0, 1.0)
    mixer_ratio = clamp((osc_a_ratio + osc_b_ratio + 0.60 * noise_ratio) / 2.0, 0.0, 1.0)

    mixer_start = clamp(float(smart.get("mixer_hot_start_ratio", 0.62)), 0.0, 0.99)
    mixer_hotness = ramp01(mixer_ratio, mixer_start, 1.0)
    mixer_pad_max = float(smart.get(f"{prefix}_mixer_pad_max", smart.get("mixer_pad_max", 5.0)))
    mixer_pad = mixer_hotness * mixer_pad_max

    # Estimate how bright/open the patch can get. Cutoff alone misses patches
    # where Env Depth throws the filter open; Env Depth alone misses dark pads.
    cutoff_raw = clamp(float(d[P["cutoff"]]), 0.0, 127.0)
    env_amt_raw = clamp(float(d[P["filter_env_amount"]]), 0.0, 127.0)
    f_attack_raw = clamp(float(d[P["filter_attack"]]), 0.0, 127.0)
    # Slow filter attacks are less likely to create an immediate loud peak.
    attack_factor = 1.0 - (float(smart.get("slow_filter_attack_reduction", 0.60)) * ramp01(f_attack_raw, 60.0, 120.0))
    env_open_weight = float(smart.get("filter_env_open_weight", 0.55))
    filter_open_est = clamp(cutoff_raw + env_amt_raw * env_open_weight * attack_factor, 0.0, 127.0)
    filter_hotness = ramp01(filter_open_est, float(smart.get("filter_open_start_raw", 62.0)), float(smart.get("filter_open_full_raw", 127.0)))
    filter_pad_max = float(smart.get(f"{prefix}_filter_pad_max", smart.get("filter_pad_max", 10.0)))
    filter_pad = filter_hotness * filter_pad_max

    # Resonance can add a focused peak even when the rest of the patch is not obviously loud.
    # Keep this mostly inactive below halfway so normal low/mid-resonance patches do not move.
    resonance_raw = clamp(float(d[P["resonance"]]), 0.0, 127.0)
    resonance_hotness = ramp01(
        resonance_raw,
        float(smart.get("resonance_pad_start_raw", 60.0)),
        float(smart.get("resonance_pad_full_raw", 120.0)),
    )
    resonance_pad_max = float(smart.get(f"{prefix}_resonance_pad_max", smart.get("resonance_pad_max", 5.0)))
    resonance_pad = resonance_hotness * resonance_pad_max

    # Amp sustain/decay matters most when the mixer is already hot and the filter
    # is at least partly open. Otherwise this wrongly turns down dark pads.
    amp_sus = clamp(float(d[P["amp_sustain"]]) / 127.0, 0.0, 1.0)
    amp_dec = clamp(float(d[P["amp_decay"]]) / 127.0, 0.0, 1.0)
    amp_body = max(amp_sus, 0.45 * amp_dec)
    amp_pad_max = float(smart.get(f"{prefix}_amp_body_pad_max", smart.get("amp_body_pad_max", 4.0)))
    amp_pad = amp_pad_max * amp_body * mixer_hotness * max(filter_hotness, 0.25)

    combo_pad_max = float(smart.get(f"{prefix}_combo_pad_max", smart.get("combo_pad_max", 8.0)))
    combo_pad = combo_pad_max * mixer_hotness * filter_hotness

    sync_on = int(d[P["osc_sync"]]) != 0
    sync_pad = float(smart.get("sync_pad", 6.0)) if sync_on else 0.0

    raw_voice_count = int(d[P["unison_voice_count"]])
    nvoices = prophet_unison_voice_count_to_repro(raw_voice_count, profile) if unison_on else int(profile.get("unison", {}).get("poly_nvoices", 8))
    voice_pad = 0.0
    if unison_on:
        voice_pad = max(0.0, float(nvoices - 1)) * float(smart.get("unison_voice_count_pad_per_extra_voice", 2.5))

    total_pad = mixer_pad + filter_pad + resonance_pad + combo_pad + amp_pad + sync_pad + voice_pad
    value = clamp(upper - total_pad, lower, upper)
    note = (
        f"smart patch output: mode={prefix}, upper={upper:.2f}, lower={lower:.2f}, "
        f"nvoices={nvoices}, voice_pad={voice_pad:.2f}, mixer={mixer_ratio:.2f}, "
        f"mixer_hot={mixer_hotness:.2f}, mixer_pad={mixer_pad:.2f}, "
        f"filter_open_est={filter_open_est:.1f}, filter_hot={filter_hotness:.2f}, "
        f"filter_pad={filter_pad:.2f}, resonance={resonance_raw:.1f}, "
        f"resonance_hot={resonance_hotness:.2f}, resonance_pad={resonance_pad:.2f}, "
        f"combo_pad={combo_pad:.2f}, amp_body={amp_body:.2f}, amp_pad={amp_pad:.2f}, "
        f"sync={'on' if sync_on else 'off'}, sync_pad={sync_pad:.2f}, "
        f"total_pad={total_pad:.2f}, output={value:.2f}"
    )
    return float(value), note


def apply_unison_voice_mode(h2p: H2PTemplate, report: List[Dict[str, Any]], profile: Dict[str, Any], d: List[int]) -> None:
    cfg = profile.get("unison", {})
    enabled = bool(cfg.get("enabled", True)) and bool(profile.get("experimental", {}).get("map_unison", True))
    unison_on = int(d[P["unison_on"]]) != 0
    raw_count = int(d[P["unison_voice_count"]])

    if enabled and unison_on:
        logic_on = int(cfg.get("logic_on", 1))
        nvoices = prophet_unison_voice_count_to_repro(raw_count, profile)
        set_and_report(h2p, report, "Voice", "Logic", logic_on, "unison_on", d[P["unison_on"]], "Prophet Unison On -> RePro Unison on")
        set_and_report(h2p, report, "Voice", "NVoices", nvoices, "unison_voice_count", raw_count, "Prophet unison voice count -> RePro unison voice count; clamped/defaulted by profile")
    else:
        logic_off = int(cfg.get("logic_off", 0))
        poly_nvoices = int(cfg.get("poly_nvoices", 8))
        note = "Prophet Unison Off -> RePro poly mode; voice count kept/set to profile poly_nvoices" if enabled else "unison mapping disabled in profile"
        set_and_report(h2p, report, "Voice", "Logic", logic_off, "unison_on", d[P["unison_on"]], note)
        set_and_report(h2p, report, "Voice", "NVoices", poly_nvoices, "unison_voice_count", raw_count, note)


def apply_mapping(patch: ProphetPatch, template: H2PTemplate, profile: Dict[str, Any]) -> Tuple[H2PTemplate, List[Dict[str, Any]]]:
    d = patch.data
    out = template.clone()
    report: List[Dict[str, Any]] = []

    # Set RePro-5 final output level. v1.7 supports unison-aware output
    # because RePro unison patches get loud quickly.
    output_cfg = profile.get("global_output", {})
    if output_cfg.get("enabled", True):
        out_section = str(output_cfg.get("section", "main"))
        out_key = str(output_cfg.get("key", "CcOp"))
        unison_on_for_output = int(d[P["unison_on"]]) != 0
        output_mode = str(output_cfg.get("mode", "fixed"))
        if output_mode == "smart_patch":
            out_value, out_note = calculate_smart_patch_output(profile, d)
        elif output_mode == "smart_unison":
            if unison_on_for_output:
                out_value, out_note = calculate_smart_patch_output(profile, d)
            else:
                out_value = float(output_cfg.get("poly_value", output_cfg.get("value", 50.0)))
                out_note = "smart unison final output: Prophet Unison Off -> poly output level"
        elif output_mode == "unison_aware":
            if unison_on_for_output:
                out_value = float(output_cfg.get("unison_value", output_cfg.get("value", 33.0)))
                out_note = "unison-aware final output: Prophet Unison On -> lower RePro output level"
            else:
                out_value = float(output_cfg.get("poly_value", output_cfg.get("value", 50.0)))
                out_note = "unison-aware final output: Prophet Unison Off -> higher RePro output level"
        else:
            out_value = float(output_cfg.get("value", 40.0))
            out_note = "default final output level from profile"
        set_and_report(out, report, out_section, out_key, out_value, "repro_final_output", int(unison_on_for_output), out_note)

    # Reserve MM1/MM2 for Prophet aftertouch behavior before other mapping.
    # Later sections do not use MM1/MM2, so these assignments stay intact.
    apply_aftertouch_matrix(out, report, profile, d)

    # Map Prophet unison mode to RePro voice logic before oscillator/filter mapping.
    apply_unison_voice_mode(out, report, profile, d)

    # Oscillator wave switches and basic controls.
    set_and_report(out, report, "OscA", "SawOn", b(d[P["osc_a_saw"]]), "osc_a_saw", d[P["osc_a_saw"]])
    set_and_report(out, report, "OscA", "RectOn", b(d[P["osc_a_square"]]), "osc_a_square", d[P["osc_a_square"]])
    set_and_report(out, report, "OscB", "SawOn", b(d[P["osc_b_saw"]]), "osc_b_saw", d[P["osc_b_saw"]])
    set_and_report(out, report, "OscB", "TriOn", b(d[P["osc_b_tri"]]), "osc_b_tri", d[P["osc_b_tri"]])
    set_and_report(out, report, "OscB", "RectOn", b(d[P["osc_b_square"]]), "osc_b_square", d[P["osc_b_square"]])

    set_and_report(out, report, "OscA", "PWidth", xform(profile, "osc_a_pw", d[P["osc_a_pw"]]), "osc_a_pw", d[P["osc_a_pw"]])
    set_and_report(out, report, "OscB", "PWidth", xform(profile, "osc_b_pw", d[P["osc_b_pw"]]), "osc_b_pw", d[P["osc_b_pw"]])
    set_and_report(out, report, "OscA", "Sync", b(d[P["osc_sync"]]), "osc_sync", d[P["osc_sync"]])
    set_and_report(out, report, "OscB", "LowFrq", b(d[P["osc_b_low_freq"]]), "osc_b_low_freq", d[P["osc_b_low_freq"]])
    set_and_report(out, report, "OscB", "KPitch", b(d[P["osc_b_keyboard"]]), "osc_b_keyboard", d[P["osc_b_keyboard"]])
    set_and_report(out, report, "OscB", "Fine", xform(profile, "osc_b_fine", d[P["osc_b_fine"]]), "osc_b_fine", d[P["osc_b_fine"]])

    if profile.get("osc_frequency", {}).get("enabled", True):
        a_oct, a_freq = prophet_freq_to_repro_oct_freq(d[P["osc_a_freq"]], profile)
        b_oct, b_freq = prophet_freq_to_repro_oct_freq(d[P["osc_b_freq"]], profile)
        quant_note = f"coarse freq centered RePro mapping from Prophet raw frequency; semitone_quantize={profile.get('osc_frequency', {}).get('semitone_quantize', 'floor')}; octave_boundary_minus_one_fix={profile.get('osc_frequency', {}).get('round_up_octave_boundary_minus_one', True)}; normalize_plus_12={profile.get('osc_frequency', {}).get('normalize_plus_12_to_next_octave', True)}; global_offset={profile.get('osc_frequency', {}).get('repro_global_semitone_offset', -12)}; raw_max={profile.get('osc_frequency', {}).get('prophet_raw_max', 120)}"
        set_and_report(out, report, "OscA", "Oct", a_oct, "osc_a_freq", d[P["osc_a_freq"]], "coarse freq octave from Prophet raw frequency")
        set_and_report(out, report, "OscA", "Freq", a_freq, "osc_a_freq", d[P["osc_a_freq"]], quant_note)
        set_and_report(out, report, "OscB", "Oct", b_oct, "osc_b_freq", d[P["osc_b_freq"]], "coarse freq octave from Prophet raw frequency")
        set_and_report(out, report, "OscB", "Freq", b_freq, "osc_b_freq", d[P["osc_b_freq"]], quant_note)
    else:
        report.append({"prophet_parameter": "osc_a_freq", "raw_value": d[P["osc_a_freq"]], "repro_section": "", "repro_key": "", "repro_value": "", "note": "osc frequency mapping disabled in profile; template kept"})
        report.append({"prophet_parameter": "osc_b_freq", "raw_value": d[P["osc_b_freq"]], "repro_section": "", "repro_key": "", "repro_value": "", "note": "osc frequency mapping disabled in profile; template kept"})

    # Mixer and glide.
    set_and_report(out, report, "Glide", "Amt", xform(profile, "glide_rate", d[P["glide_rate"]]), "glide_rate", d[P["glide_rate"]])
    set_and_report(out, report, "MIX", "OscA", xform(profile, "osc_a_level", d[P["osc_a_level"]]), "osc_a_level", d[P["osc_a_level"]])
    set_and_report(out, report, "MIX", "OscB", xform(profile, "osc_b_level", d[P["osc_b_level"]]), "osc_b_level", d[P["osc_b_level"]])
    set_and_report(out, report, "MIX", "Noise", xform(profile, "noise_level", d[P["noise_level"]]), "noise_level", d[P["noise_level"]])

    # Filter. Determine the target RePro filter model first so cutoff can be model-aware.
    rev_value = str(int(d[P["filter_rev"]]))
    rev_name = profile.get("filter_revision_values", {}).get(rev_value, "rev_3")
    model_name = profile.get("filter_revision_mapping", {}).get(rev_name, "poly")
    chip_value = int(profile.get("repro_filter_chips", {}).get(model_name, 3))

    # v1.2: cutoff compensation is source-filter and target-model aware.
    # Example: Prophet Rev 1/2 -> RePro Driven uses cutoff_rev_1_2_driven.
    transforms = profile.get("transforms", {})
    source_target_cutoff_transform = f"cutoff_{rev_name}_{model_name}"
    legacy_cutoff_transform = f"cutoff_{model_name}"
    if source_target_cutoff_transform in transforms:
        cutoff_transform = source_target_cutoff_transform
    elif legacy_cutoff_transform in transforms:
        cutoff_transform = legacy_cutoff_transform
    else:
        cutoff_transform = "cutoff"
    cutoff_value = xform_transform(profile, cutoff_transform, d[P["cutoff"]], "cutoff")
    cutoff_note = f"filter-aware cutoff: {rev_name} -> {model_name} uses transform '{cutoff_transform}'"
    set_and_report(out, report, "Filter", "Cutoff", cutoff_value, "cutoff", d[P["cutoff"]], cutoff_note)
    set_and_report(out, report, "Filter", "Reso", xform(profile, "resonance", d[P["resonance"]]), "resonance", d[P["resonance"]])
    kt = str(int(d[P["filter_keytrack"]]))
    key_amt = float(profile.get("filter_keytrack_values", {}).get(kt, 75.0))
    set_and_report(out, report, "Filter", "KeyAmt", key_amt, "filter_keytrack", d[P["filter_keytrack"]], "0=off, 1=half, 2=full")
    set_and_report(out, report, "Filter", "EnvAmt", xform(profile, "filter_env_amount", d[P["filter_env_amount"]]), "filter_env_amount", d[P["filter_env_amount"]])

    set_and_report(out, report, "FltrIC", "Chip", chip_value, "filter_rev", d[P["filter_rev"]], f"assumed {rev_name} -> {model_name}")

    osc_chip_cfg = profile.get("repro_oscillator_chips", {})
    if osc_chip_cfg.get("enabled", False):
        osc_chip_value = None
        by_rev = osc_chip_cfg.get("when_filter_mapping", {})
        if isinstance(by_rev, dict):
            model_map = by_rev.get(rev_name, {})
            if isinstance(model_map, dict):
                osc_chip_value = model_map.get(model_name)
        if osc_chip_value is not None:
            osc_chip_value = int(osc_chip_value)
            osc_chip_note = f"oscillator tweak from filter pairing {rev_name} -> {model_name}; Chip={osc_chip_value} (P5 Old)"
            set_and_report(out, report, "OscAIC", "Chip", osc_chip_value, "filter_rev", d[P["filter_rev"]], osc_chip_note)
            set_and_report(out, report, "OscBIC", "Chip", osc_chip_value, "filter_rev", d[P["filter_rev"]], osc_chip_note)

    # LFO and global mod destinations.
    set_and_report(out, report, "LFO", "Freq", xform(profile, "lfo_freq", d[P["lfo_freq"]]), "lfo_freq", d[P["lfo_freq"]])
    set_and_report(out, report, "LFO", "Saw", b(d[P["lfo_saw"]]), "lfo_saw", d[P["lfo_saw"]])
    set_and_report(out, report, "LFO", "Triang", b(d[P["lfo_tri"]]), "lfo_tri", d[P["lfo_tri"]])
    set_and_report(out, report, "LFO", "Sqre", b(d[P["lfo_square"]]), "lfo_square", d[P["lfo_square"]])
    set_and_report(out, report, "GMod", "SrcMix", xform(profile, "lfo_source_mix", d[P["lfo_source_mix"]]), "lfo_source_mix", d[P["lfo_source_mix"]])

    if profile.get("experimental", {}).get("map_lfo_initial_amount_to_gmod_lowlim", True):
        set_and_report(out, report, "GMod", "LowLim", xform(profile, "lfo_initial_amount", d[P["lfo_initial_amount"]]), "lfo_initial_amount", d[P["lfo_initial_amount"]], "experimental: initial LFO amount -> GMod.LowLim")

    if profile.get("experimental", {}).get("map_lfo_destinations", True):
        set_and_report(out, report, "OscA", "GModFM", b(d[P["lfo_freq_a"]]), "lfo_freq_a", d[P["lfo_freq_a"]])
        set_and_report(out, report, "OscB", "GModFM", b(d[P["lfo_freq_b"]]), "lfo_freq_b", d[P["lfo_freq_b"]])
        set_and_report(out, report, "OscA", "GModPWM", b(d[P["lfo_pw_a"]]), "lfo_pw_a", d[P["lfo_pw_a"]])
        set_and_report(out, report, "OscB", "GModPWM", b(d[P["lfo_pw_b"]]), "lfo_pw_b", d[P["lfo_pw_b"]])
        set_and_report(out, report, "Filter", "GMod", b(d[P["lfo_filter"]]), "lfo_filter", d[P["lfo_filter"]])

    # Poly Mod / Voice Mod. Experimental but musically useful.
    if profile.get("experimental", {}).get("map_poly_mod", True):
        set_and_report(out, report, "VMod", "EnvAmt", xform(profile, "poly_mod_filter_env_amount", d[P["poly_mod_filter_env_amount"]]), "poly_mod_filter_env_amount", d[P["poly_mod_filter_env_amount"]])
        set_and_report(out, report, "VMod", "OscBAmt", xform(profile, "poly_mod_osc_b_amount", d[P["poly_mod_osc_b_amount"]]), "poly_mod_osc_b_amount", d[P["poly_mod_osc_b_amount"]])
        set_and_report(out, report, "OscA", "VModFM", b(d[P["poly_mod_freq_a"]]), "poly_mod_freq_a", d[P["poly_mod_freq_a"]])
        set_and_report(out, report, "OscA", "VModPWM", b(d[P["poly_mod_pw"]]), "poly_mod_pw", d[P["poly_mod_pw"]], "RePro target available on OscA")
        set_and_report(out, report, "Filter", "VMod", b(d[P["poly_mod_filter"]]), "poly_mod_filter", d[P["poly_mod_filter"]])

    # Vintage -> RePro detune. Tunable in profile.
    set_and_report(out, report, "VDetune", "Amount", xform(profile, "vintage", d[P["vintage"]]), "vintage", d[P["vintage"]], "approximate: Prophet Vintage -> RePro Detune")

    # Envelopes and velocity.
    f_rel = xform(profile, "filter_release", d[P["filter_release"]])
    a_rel = xform(profile, "amp_release", d[P["amp_release"]])
    if int(d[P["release_switch"]]) == 0 and profile.get("release_switch_off") == "zero_releases":
        f_rel = 0.0
        a_rel = 0.0
        rel_note = "release switch off -> forced to 0"
    else:
        rel_note = "release switch on or ignored"

    set_and_report(out, report, "FEnv", "Atk", xform(profile, "filter_attack", d[P["filter_attack"]]), "filter_attack", d[P["filter_attack"]])
    set_and_report(out, report, "FEnv", "Dec", xform(profile, "filter_decay", d[P["filter_decay"]]), "filter_decay", d[P["filter_decay"]])
    set_and_report(out, report, "FEnv", "Sus", xform(profile, "filter_sustain", d[P["filter_sustain"]]), "filter_sustain", d[P["filter_sustain"]])
    set_and_report(out, report, "FEnv", "Rel", f_rel, "filter_release", d[P["filter_release"]], rel_note)
    f_vel = float(profile.get("velocity_on_value", {}).get("filter", 25.0)) if int(d[P["velocity_filter"]]) else 0.0
    set_and_report(out, report, "FEnv", "VelDep", f_vel, "velocity_filter", d[P["velocity_filter"]], "Prophet is on/off; profile sets depth when on")

    set_and_report(out, report, "AEnv", "Atk", xform(profile, "amp_attack", d[P["amp_attack"]]), "amp_attack", d[P["amp_attack"]])
    set_and_report(out, report, "AEnv", "Dec", xform(profile, "amp_decay", d[P["amp_decay"]]), "amp_decay", d[P["amp_decay"]])
    set_and_report(out, report, "AEnv", "Sus", xform(profile, "amp_sustain", d[P["amp_sustain"]]), "amp_sustain", d[P["amp_sustain"]])
    set_and_report(out, report, "AEnv", "Rel", a_rel, "amp_release", d[P["amp_release"]], rel_note)
    a_vel = float(profile.get("velocity_on_value", {}).get("amp", 25.0)) if int(d[P["velocity_amp"]]) else 0.0
    set_and_report(out, report, "AEnv", "VelDep", a_vel, "velocity_amp", d[P["velocity_amp"]], "Prophet is on/off; profile sets depth when on")

    return out, report


def safe_filename(name: str) -> str:
    # Do not call clean_program_name() here. Filename templates may intentionally
    # include location prefixes such as G2_P01, and clean_program_name() strips
    # those prefixes for human patch-name normalization.
    name = str(name)[:120]
    # Windows-invalid filename chars: <>:"/\|?* plus control chars.
    name = re.sub(r'[<>:"/\\|?*\x00-\x1F]+', "_", name)
    name = re.sub(r"\s+", " ", name).strip(" ._")
    return name or "patch"


def unique_output_path(folder: Path, stem: str, suffix: str = ".h2p") -> Path:
    stem = safe_filename(stem)
    candidate = folder / f"{stem}{suffix}"
    if not candidate.exists():
        return candidate
    for i in range(2, 10000):
        candidate = folder / f"{stem}_{i}{suffix}"
        if not candidate.exists():
            return candidate
    raise RuntimeError(f"Could not find a unique filename for {stem}{suffix}")


def write_report_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    fieldnames = ["file", "program_name", "patch_label", "pair_label", "layer", "stack_mode", "dump_type", "group_raw", "program_raw", "prophet_parameter", "raw_value", "repro_section", "repro_key", "repro_value", "note"]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def convert(args: argparse.Namespace) -> int:
    profile = load_profile(args.profile)
    template_text = args.template.read_text(encoding="utf-8", errors="replace")
    template = H2PTemplate(template_text)
    args.out.mkdir(parents=True, exist_ok=True)

    manual_names = load_names_file(args.names_file)
    manual_name_iter: Iterator[str] = iter(manual_names)

    # v1.4 behavior: when converting multiple SysEx files, keep each source
    # bank/soundset in its own output folder unless --flat-output is requested.
    separate_source_folders = (not args.flat_output) and (args.all_syx or len(args.inputs) > 1)

    all_report_rows: List[Dict[str, Any]] = []
    total = 0
    for syx_path in args.inputs:
        patches = parse_prophet_patches(syx_path, loose_fallback=not args.no_loose)
        if not patches:
            print(f"No Prophet-5 Rev 4 program/edit-buffer dumps found in {syx_path}", file=sys.stderr)
            continue

        if separate_source_folders:
            source_out = args.out / safe_filename(syx_path.stem)
        else:
            source_out = args.out
        source_out.mkdir(parents=True, exist_ok=True)

        for patch in patches:
            if not args.no_program_names:
                # Manual names file has highest priority. Use one line per converted patch.
                try:
                    manual_name = next(manual_name_iter)
                except StopIteration:
                    manual_name = ""
                if manual_name:
                    patch.name = manual_name

            converted, patch_report = apply_mapping(patch, template, profile)
            program_name = patch.display_name if not args.no_program_names else patch.label
            context = {
                "name": program_name,
                "label": patch.label,
                "source": syx_path.stem,
                "group": "" if patch.group is None else patch.group,
                "program": "" if patch.program is None else patch.program,
                "group1": "" if patch.group is None else patch.group + 1,
                "program1": "" if patch.program is None else patch.program + 1,
                "pair_label": patch.pair_display_label,
                "layer": patch.layer_display,
                "stack_mode": patch.stack_split_mode_display,
            }
            try:
                base = args.filename_template.format(**context)
            except KeyError as exc:
                raise KeyError(f"Unknown field in --filename-template: {exc}. Allowed: {', '.join(sorted(context))}")
            if args.prefix:
                base = f"{args.prefix}{base}"
            out_path = unique_output_path(source_out, base, ".h2p")
            out_path.write_text(converted.text(), encoding="utf-8")
            total += 1

            try:
                report_file = str(out_path.relative_to(args.out))
            except ValueError:
                report_file = out_path.name

            for row in patch_report:
                report_row = {
                    "file": report_file,
                    "program_name": program_name,
                    "patch_label": patch.label,
                    "dump_type": patch.dump_type,
                    "group_raw": "" if patch.group is None else patch.group,
                    "program_raw": "" if patch.program is None else patch.program,
                    "pair_label": patch.pair_display_label,
                    "layer": patch.layer_display,
                    "stack_mode": patch.stack_split_mode_display,
                    **row,
                }
                all_report_rows.append(report_row)

            if args.dump_json:
                decoded = {
                    "source_file": str(syx_path),
                    "patch_label": patch.label,
                    "program_name": program_name,
                    "dump_type": patch.dump_type,
                    "group_raw": patch.group,
                    "program_raw": patch.program,
                    "pair_label": patch.pair_display_label,
                    "layer": patch.layer_display,
                    "stack_mode": patch.stack_split_mode_display,
                    "program_bytes": {PARAMETER_NAMES.get(i, f"byte_{i}"): patch.data[i] for i in range(54)},
                }
                (source_out / f"{safe_filename(base)}.decoded.json").write_text(json.dumps(decoded, indent=2), encoding="utf-8")

            print(f"Wrote {out_path}")

    if all_report_rows and separate_source_folders:
        report_path = args.out / "conversion_report_all.csv"
        write_report_csv(report_path, all_report_rows)
        print(f"Wrote {report_path}")
    elif all_report_rows:
        report_path = args.out / "conversion_report.csv"
        write_report_csv(report_path, all_report_rows)
        print(f"Wrote {report_path}")

    print(f"Converted {total} patch(es).")
    return 0 if total else 2


def self_test() -> int:
    data = [(i * 37) % 256 for i in range(128)]
    packed = pack_dsi_packed_msbit(data)
    unpacked = unpack_dsi_packed_msbit(packed)
    assert len(packed) == 152, len(packed)
    assert unpacked == data, "pack/unpack roundtrip failed"
    print("Self-test OK: DSI packed MS-bit roundtrip produced 152 packed bytes for 128 data bytes.")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Convert Sequential Prophet-5 Rev 4 SysEx program dumps to u-he RePro-5 .h2p presets."
    )
    parser.add_argument("inputs", nargs="*", type=Path, help="Input .syx file(s). A bank can contain multiple concatenated program dumps.")
    parser.add_argument("--all-syx", action="store_true", help="Convert all .syx files in the current folder, or in --syx-folder if supplied.")
    parser.add_argument("--syx-folder", type=Path, default=Path("."), help="Folder used by --all-syx. Default: current folder.")
    parser.add_argument("--template", type=Path, default=Path("RePro5_INIT_All_OSCs_Off.h2p"), help="RePro-5 .h2p template to edit. Default: ./RePro5_INIT_All_OSCs_Off.h2p")
    parser.add_argument("--profile", type=Path, default=None, help="Optional JSON mapping profile. Omitted values fall back to built-in defaults.")
    parser.add_argument("--out", type=Path, default=Path("Converted_RePro5"), help="Output folder. Default: ./Converted_RePro5")
    parser.add_argument("--flat-output", action="store_true", help="Write all converted presets directly into --out, even when converting multiple .syx files. Restores pre-v1.4 behavior.")
    parser.add_argument("--prefix", default="", help="Optional filename prefix for converted presets. Default: empty")
    parser.add_argument("--filename-template", default="{name}", help="Output filename template. Fields: {name}, {label}, {pair_label}, {layer}, {stack_mode}, {source}, {group}, {program}, {group1}, {program1}. Default: {name}. For stack/split layers, {name} automatically includes pair label + layer + Stack/Split mode, e.g. G4_P01 A Stack.")
    parser.add_argument("--names-file", type=Path, default=None, help="Optional text file with one preset name per line. Overrides embedded names in conversion order.")
    parser.add_argument("--no-program-names", action="store_true", help="Ignore embedded/manual program names and use location labels instead.")
    parser.add_argument("--dump-json", action="store_true", help="Also write decoded Prophet program-byte JSON files for debugging.")
    parser.add_argument("--scan", action="store_true", help="Inspect input .syx files and print SysEx message lengths/headers plus loose parser candidates, then exit.")
    parser.add_argument("--no-loose", action="store_true", help="Disable loose fallback parser and accept only official Prophet-5 Rev 4 program/edit-buffer dumps.")
    parser.add_argument("--write-default-profile", type=Path, help="Write the built-in default mapping profile to this path and exit.")
    parser.add_argument("--self-test", action="store_true", help="Run pack/unpack self-test and exit.")

    args = parser.parse_args(argv)

    if args.self_test:
        return self_test()

    if args.write_default_profile:
        args.write_default_profile.write_text(json.dumps(default_profile(), indent=2), encoding="utf-8")
        print(f"Wrote {args.write_default_profile}")
        return 0

    if args.all_syx:
        syx_folder = args.syx_folder
        found = sorted(syx_folder.glob("*.syx"))
        # Avoid accidental duplicates if the user also supplied explicit inputs.
        existing = {p.resolve() for p in args.inputs if p.exists()}
        args.inputs.extend([p for p in found if p.resolve() not in existing])
        if not found:
            parser.error(f"--all-syx found no .syx files in {syx_folder}")

    if not args.inputs:
        parser.error("Provide at least one .syx input file, use --all-syx, or use --self-test / --write-default-profile.")

    if args.scan:
        status = 0
        for p in args.inputs:
            status = max(status, scan_sysex_file(p))
        return status

    if not args.template.exists():
        print(f"Template not found: {args.template}", file=sys.stderr)
        return 2

    return convert(args)


if __name__ == "__main__":
    raise SystemExit(main())
