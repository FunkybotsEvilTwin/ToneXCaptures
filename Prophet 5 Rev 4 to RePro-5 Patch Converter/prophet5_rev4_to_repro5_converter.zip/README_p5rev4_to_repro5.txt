Prophet-5 Rev 4 SysEx to RePro-5 Preset Python Script 2.4l
=================================================================

This Python script converts Sequential Prophet-5/10 Rev 4 SysEx program dumps
into U-he RePro-5 .h2p presets.

RePro-5 is not a Prophet Rev 4 clone, so this is not a magic one-to-one
recreation of the hardware. That said, this script was built around the idea
that the patches should be translated musically, not just numerically. A lot of
the work went into comparing the Rev 4 hardware against RePro-5, then dialing in
the conversion curves so the results landed closer by ear and by measurement.

That includes measured envelope timing adjustments, filter cutoff compensation
using self-resonance tests, scaled glide behavior, modulation-depth tuning,
oscillator tuning cleanup, and smarter output-level handling. In a few places,
the best result was not a literal knob match. For example, when a Prophet
Rev 1/2 filter is detected, the script maps it to RePro-5’s Driven filter and
enables the P5 Old oscillator tweak, because that combination felt like the
better musical fit. The goal is to preserve the character and behavior of the
original patch as much as practical inside RePro-5, rather than pretending both
synths respond identically.

The script can convert every .syx file placed in the root folder, clean up
program names, put each bank into its own folder, and create a combined
conversion report. So if you have multiple SysEx banks, you can convert them all
in one shot.

It also uses a smart naming convention that cleans up regular single-patch names
while clearly identifying which stack and split layers belong together.

It also writes clean RePro-5 browser metadata by mapping the Prophet category byte
to RePro Categories, adding conservative Features tags from patch parameters,
and adding brief Usage notes for Velocity, Aftertouch, and Mod Wheel behavior
when those controls are assigned. Generated metadata does not include Bank or
Author tags.


For newer Prophet stack/split programs, RePro-5 cannot reproduce the actual
stack/split structure directly. Instead, the script breaks the two layers out as
separate RePro-5 presets with matching names so they stay grouped together.


Requirements
------------

You need:

- A working Python 3 environment
- U-he RePro-5
- Sequential Prophet-5/10 Rev 4 SysEx program dumps
- The script, profile, and RePro-5 template preset in the same working folder

This is a Python script, not a standalone app. It assumes you already have
Python 3 working on your computer. Setting up Python is outside the scope of this
README.


Basic setup
-----------

Create one folder for the converter. Put these files in that folder:

- p5rev4_to_repro5.py
- p5rev4_to_repro5_profile.json
- RePro5_INIT_All_OSCs_Off.h2p
- Any Prophet .syx files you want to convert

The normal workflow is to drop all of your .syx files into that same folder and
run one command to convert everything.


Windows PowerShell instructions
-------------------------------

Open PowerShell in the converter folder. Run the command at the PowerShell
prompt, not inside the Python interpreter.

To convert every .syx file in the folder:

   py .\p5rev4_to_repro5.py --all-syx --profile ".\p5rev4_to_repro5_profile.json" --out ".\Converted_RePro5_All_2_4l" --filename-template "{name}"

If your Windows Python setup uses `python` instead of `py`, use this:

   python .\p5rev4_to_repro5.py --all-syx --profile ".\p5rev4_to_repro5_profile.json" --out ".\Converted_RePro5_All_2_4l" --filename-template "{name}"


macOS instructions
------------------

Open Terminal in the converter folder. Run the command at the Terminal prompt,
not inside the Python interpreter.

To convert every .syx file in the folder:

   python3 ./p5rev4_to_repro5.py --all-syx --profile "./p5rev4_to_repro5_profile.json" --out "./Converted_RePro5_All_2_4l" --filename-template "{name}"

If macOS blocks the script because of permissions, keep running it directly
through Python as shown above. You do not need to make the script executable.


Output
------

When using `--all-syx`, the script creates one output folder. Inside that
folder, each source .syx file gets its own subfolder.

Example:

   Converted_RePro5_All_2_4l/
     Bank One/
       Patch Name.h2p
       Another Patch.h2p
     Bank Two/
       Another Patch Name.h2p
     conversion_report_all.csv

The only report file created during an all-bank conversion is:

   conversion_report_all.csv

That report is kept at the root of the output folder so the preset subfolders
stay clean.

For single-file conversion, the script writes a regular root-level:

   conversion_report.csv

After conversion, place the converted .h2p presets in your RePro-5 User Presets
folder. See the RePro-5 documentation or your RePro-5 installation for the exact
preset location on your system.


Stack and split programs
------------------------

Newer Prophet-5/10 Rev 4 firmware can store stacks and splits by linking two
program layers together.

RePro-5 does not support Prophet stacks or splits directly, so the script does
the next best thing: it exports each layer as its own RePro-5 preset.

The names are kept together so you can see which layers belong to the same
original Prophet program.

Example style:

   G4_P01 A Stack.h2p
   G4_P01 B Stack.h2p
   G4_P02 A Split.h2p
   G4_P02 B Split.h2p

This does not recreate the full performance behavior of a Prophet stack or
split. It gives you both sound layers so you can load them separately, compare
them, or rebuild the layered setup manually in a DAW.


What the script does under the hood
-----------------------------------

The script starts with a RePro-5 template preset and writes the converted
Prophet values into the readable .h2p parameter sections. It leaves the
compressed binary section alone. This matters for the FX chain: the included
2.4g template was saved directly from RePro-5 so the readable FX sections and
the hidden preset data agree on the intended FX order.

Most of the conversion behavior lives in:

   p5rev4_to_repro5_profile.json

That profile contains the mapping curves and choices used to translate Prophet
Rev 4 values into RePro-5 values.

The main idea is simple: do the translation in the way that sounds most
believable in RePro-5, even when that means not matching the Prophet knob
positions literally.

Some of the bigger decisions:

- Prophet filter revisions are mapped to RePro-5 filter models. Rev 1/2 maps to
  the Driven filter with the P5 Old oscillator tweak enabled. Rev 3 maps to the
  Poly filter.

- Filter cutoff uses compensation curves based on self-resonance measurements,
  instead of assuming the same knob value means the same cutoff frequency.

- Envelopes use measured timing curves for attack, decay, and release, so the
  converted envelopes respond more like the hardware.

- Glide is scaled down because RePro-5’s glide range is longer.

- Prophet Initial Amount is mapped more conservatively to RePro-5’s GMod lower
  limit, because the direct translation was too strong and made low/moderate LFO
  amount settings come in too hot.

- Oscillator pitch and fine tuning are cleaned up so awkward stored values land
  on practical RePro-5 settings. As of 1.1, the oscillator coarse-frequency
  mapping uses RePro-5's Oct 0..3 plus Freq -12..+12 range, which better matches
  the Prophet's four-octave oscillator span.

- Voice Mod / Poly Mod is tuned by behavior. Osc B modulation uses a musical
  interval-based curve, while filter-envelope modulation stays full range.

- Aftertouch is mapped into reserved RePro-5 mod matrix slots.

- Unison mode and voice count are mapped where possible.

- The included RePro-5 init template sets the default FX order/configuration to
  Velvet, Lyrebird, ResQ, Drench, and Sonic Conditioner. The FX remain bypassed
  by default, but they appear in that order if enabled.

- Output level is scored per patch to keep levels reasonable. The script looks
  at mixer levels, resonance, filter openness, envelope behavior, sync, unison,
  and voice count, then trims the final RePro-5 output level when needed.

The goal is not to perfectly recreate every internal Prophet behavior. The goal
is to get a musically useful RePro-5 version of the patch with sane levels, good
naming, and the important architecture translated as closely as practical.


Editing the mappings
--------------------

If you want to tweak how the conversion behaves, start with:

   p5rev4_to_repro5_profile.json

That is where most of the useful mapping decisions live.

You can adjust things like:

- Filter model choices
- Cutoff compensation curves
- Envelope timing curves
- Glide scaling
- Voice Mod / Poly Mod curves
- Output level scoring
- Aftertouch depth
- Unison behavior

The script is plain Python and the profile is JSON, so nothing is locked down. If
you find better mappings, improve it and share the results.


Limitations
-----------

This script does a lot, but it is still a conversion script, not a hardware
emulator.

Known limitations:

- RePro-5 is not a Prophet-5/10 Rev 4 clone.
- Prophet stacks and splits are broken out into separate presets, not recreated
  as true stack/split performances.
- Some Prophet behaviors do not have exact RePro-5 equivalents.
- Some mappings are based on measured tests and listening rather than official
  documentation.
- Output level scoring is a practical heuristic, not true loudness normalization.
- A converted preset may still need a little manual adjustment inside RePro-5.

Even with those limits, the script should get most compatible Rev 4 patches much
closer than a raw knob-by-knob translation.


Recommended workflow
--------------------

1. Put all of the .syx banks you want to convert into the converter folder.
2. Run the all-syx command.
3. Open the output folder and check the bank folders.
4. Copy the converted presets into your RePro-5 User Presets folder.
5. Open RePro-5, rescan or refresh presets if needed, and audition.
6. Use the conversion report if you want to inspect what was converted.


License
-------

This script is provided for personal and non-commercial use only, and may not be
resold, repackaged, redistributed as part of a paid product, or otherwise used
for commercial purposes without explicit permission from the author.


Disclaimer
----------

This is an unofficial converter. It is not affiliated with, endorsed by, or
supported by Sequential, U-he, or any third-party sound designers.

Sequential, Prophet-5, Prophet-10, U-he, RePro-5, and any other product or
company names mentioned here are trademarks or registered trademarks of their
respective owners.

Use it on copies of your SysEx files, not your only copy.

If you improve the mappings, fix edge cases, or make the script better, please
share your changes so other Prophet/RePro users can benefit from them.

# Change Log

## July 3, 2026

* Added RePro-5 Usage metadata for patches that use Velocity, Aftertouch, or Mod Wheel/LFO destinations. Generated metadata still omits Bank and Author tags.
* Expanded RePro-5 metadata name matching for additional obvious instrument clues, including plucks, poly patches, unison-named mono patches, strings/harp/cello, chimes/bells, organs/harmonium/accordion, vibes/mallets, Wurli/Wurly/tines, nylon/guitar names, brass/wind names, voices/choirs, 808/drum names, helicopter/FX, and arpeggiators.
* Added RePro-5 browser metadata generation from the Prophet category byte, patch names, and conservative parameter heuristics. Generated metadata omits Bank and Author tags.
* Refined metadata mapping for brass-like names such as Sax, Trumpet, and Horn, bell names, Clav names, and additional acronym cleanup for EP, VCO, UFO, and CP.
* Removed preset metadata from the bundled template.
* Replaced the bundled RePro-5 init template with a RePro-saved preset so the FX chain order is preserved by RePro-5 when presets load. The intended default order is Velvet, Lyrebird, ResQ, Drench, and Sonic Conditioner. FX remain bypassed/off by default.


## July 2, 2026

* Improved Osc B Fine Tune mapping using measured Prophet Rev 4 pitch offsets.
* Changed larger Osc B Fine Tune offsets to use RePro Osc B Frequency instead of forcing everything through RePro Osc B Fine Tune.
* Added a RePro Mixer Noise default of 0.3 when Prophet Noise is off to better match hardware behavior.
* Updated Glide Time mapping to better match hardware.
* Updated the intended RePro FX order/configuration to Velvet, Lyrebird, ResQ, Drench, and Sonic Conditioner. FX remain bypassed/off by default.
* Validated PWM mapping against hardware. No changes needed.

## July 1, 2026

* Updated Resonance mapping separately for Rev 3/Poly and Rev 1/2/Driven filter behavior. This helps compensate for RePro-5 reaching stronger resonance at equivalent settings.
* Updated Amp Velocity On to use RePro Amp Envelope Velocity Depth 100 to better match hardware.
* Updated Filter Velocity On to use RePro Filter Envelope Velocity Depth 91 to better match hardware.
* Updated Filter Envelope Amount mapping using measured hardware-to-RePro comparison points.
* Added Prophet/SoundTower-style patch locations, such as Factory 2 5-6, to the report for easier patch lookup.

## June 30, 2026

* Updated Filter Cutoff mapping separately for Rev 3/Poly and Rev 1/2/Driven filter behavior.
* Added measured Attack, Decay, and Release envelope time mappings to better match hardware.
* Updated Vintage/Detune mapping to better match tighter and driftier Prophet behavior.
* Added oscillator top-end clamping so high Prophet oscillator frequency values do not overshoot the hardware’s maximum pitch.

## June 29, 2026

* Added stack/split program handling.
* Added clearer filename templates for exported RePro patches.
* Added patch-name cleanup for title casing, acronyms, decade forms, ordinals, and other case issues.

## June 28, 2026

* Initial version.
* Added initial Rev 1/2 vs Rev 3 filter model selection, using RePro Driven for Rev 1/2-style patches and RePro Poly for Rev 3-style patches.
* Fixed the oscillator octave mapping offset.
* Added smart output-level mapping to reduce overly loud or overly quiet converted patches.
* Added output adjustment based on mixer level, filter openness, resonance, envelopes, and unison behavior.
* Added expanded conversion reporting for easier patch comparison and debugging.

# Known Limitations

* Prophet Rev 4 polyphonic glide cannot be reproduced directly in RePro-5 poly mode.
* Some patches that rely heavily on audio-rate Osc B modulation or Filter FM may need manual adjustment.
