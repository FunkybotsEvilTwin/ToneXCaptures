Prophet-5 Rev 4 SysEx to RePro-5 Preset Converter — Version 2.5.14
================================================================


Introduction
------------

This Python script converts Sequential Prophet-5/10 Rev 4 SysEx program dumps
into u-he RePro-5 .h2p presets.

RePro-5 is not a Prophet Rev 4 clone, so the conversion cannot reproduce every
hardware behavior exactly. The converter is designed as a musical translation:
it uses hardware measurements and listening comparisons to make the converted
patches behave and sound as close as practical inside RePro-5.

The converter can:

- Convert every .syx file placed in the converter folder in one operation.
- Convert regular programs as well as newer Stack and Split programs.
- Clean up preset names and preserve useful acronyms.
- Add RePro browser metadata, usage notes, source SysEx names, and Prophet
  bank/program locations.
- Create a combined conversion report.
- Apply measured mappings and Smart Volume matching automatically.


Requirements
------------

You need:

- Python 3
- u-he RePro-5
- Sequential Prophet-5/10 Rev 4 SysEx program dumps
- The files included in this package

This is a Python script, not a standalone application. Python must be installed
before running it.


Basic Setup
-----------

1. Extract this package into its own folder.
2. Copy the Prophet .syx files you want to convert into that folder.
3. Run the launcher for your operating system:

   Windows:
      Double-click run_converter.bat

   macOS:
      Double-click run_converter.command

      If macOS blocks it, right-click the file and choose Open. You can also
      open Terminal in the folder and run:

         sh ./run_converter.command

4. The converted presets will be written to:

      Converted_RePro5_All_2_5_14


Recommended Workflow
--------------------

1. Put all of the .syx banks you want to convert into the converter folder.
2. Run the appropriate launcher, or use the manual command below.
3. Open the Converted_RePro5_All_2_5_14 folder and check the bank subfolders.
4. Copy the converted .h2p presets into your RePro-5 User Presets folder.
5. Open RePro-5 and refresh or rescan the preset browser if needed.
6. Audition the converted presets.
7. Use conversion_report_all.csv if you want to inspect the conversion details.


Manual Commands
---------------

Windows PowerShell:

   py .\p5rev4_to_repro5.py --all-syx --profile ".\p5rev4_to_repro5_profile.json" --out ".\Converted_RePro5_All_2_5_14" --filename-template "{name}"

If your Python installation uses python instead of py:

   python .\p5rev4_to_repro5.py --all-syx --profile ".\p5rev4_to_repro5_profile.json" --out ".\Converted_RePro5_All_2_5_14" --filename-template "{name}"

macOS or Linux:

   python3 ./p5rev4_to_repro5.py --all-syx --profile "./p5rev4_to_repro5_profile.json" --out "./Converted_RePro5_All_2_5_14" --filename-template "{name}"


Output
------

When converting all SysEx files, the converter creates one output folder.
Each source .syx file receives its own subfolder, and the combined report stays
at the root.

Example:

   Converted_RePro5_All_2_5_14/
      Bank One/
         Patch Name.h2p
         Another Patch.h2p
      Bank Two/
         Another Patch Name.h2p
      conversion_report_all.csv

For a single-file conversion, the report is named conversion_report.csv.


Stack and Split Programs
------------------------

Newer Prophet-5/10 Rev 4 firmware can store Stack and Split programs by linking
two layers.

RePro-5 cannot reproduce the complete Prophet Stack or Split structure inside a
single preset. The converter exports each layer as a separate .h2p preset and
uses matching names so the layers remain grouped together.

This gives you both sounds for comparison or for rebuilding the layered
performance manually in a DAW.


Preset Metadata
---------------

The converter adds useful RePro-5 browser metadata where possible, including:

- Prophet bank/program location
- Source SysEx filename
- Categories
- Features
- Usage notes for Velocity, Aftertouch, and Mod Wheel assignments

Generated presets do not add Bank or Author tags.


Customization
-------------

Most conversion behavior is controlled by:

   p5rev4_to_repro5_profile.json

The script is plain Python and the profile is JSON. Advanced users can edit the
profile to change filter choices, mapping curves, Smart Volume behavior, glide,
modulation, oscillator, envelope, and unison settings.


Limitations
-----------

- RePro-5 is not a Prophet-5/10 Rev 4 emulator.
- Prophet Stack and Split programs are exported as separate presets rather than
  recreated as true layered performances.
- Prophet Rev 4 polyphonic glide cannot be reproduced directly in RePro-5 poly
  mode.
- RePro has one shared Poly Mod amount per source, so patches that route one
  source to both Filter and Osc A Frequency require a compromise.
- PWM-only Poly Mod routing uses the corresponding measured frequency-source
  mapping as a practical fallback.
- The hardware Osc B-to-Filter range exceeds RePro at the highest settings, so
  the upper part of the range must clamp to RePro's maximum.
- Some patches that depend heavily on audio-rate Osc B modulation or Filter FM
  may need manual adjustment.
- Smart Volume is a practical matching system, not true loudness normalization.
- Some converted presets may still benefit from small manual adjustment.


License
-------

This script is provided for personal and non-commercial use only. It may not be
resold, repackaged, redistributed as part of a paid product, or otherwise used
for commercial purposes without explicit permission from the author.


Disclaimer
----------

This is an unofficial converter. It is not affiliated with, endorsed by, or
supported by Sequential, u-he, or any third-party sound designers.

Sequential, Prophet-5, Prophet-10, u-he, RePro-5, and any other product or
company names mentioned here are trademarks or registered trademarks of their
respective owners.

Use copies of your SysEx files rather than your only copy.


Change Log
----------

## July 20, 2026 — Version 2.5.14

* Added batch (.bat) and command (.command) to make the scripts easier to run on Windows and Mac respectively.
* Improved Rev 1/2 filter matching through updated filter selection and tuning.
* Improved unison patch conversion, including corrected voice counts, improved resonance, and filter envelope voice variation for a closer match to Prophet hardware.
* Improved amplifier envelope (Attack, Decay, Sustain, and Release) mapping using new hardware measurements.
* Greatly improved Smart Volume matching across patches using a new parameter-based output model.
* Added support for the Prophet Rev4 firmware 2.0.4 continuous per-program Velocity and Aftertouch modulation depth controls.
* Improved Standard LFO, Poly Mod, Osc B Low Frequency, and Osc B Fine Tune mapping using new hardware measurements.
* Improved preset metadata by adding Prophet bank/program locations and source SysEx file names to preset descriptions.
* Numerous additional refinements and bug fixes throughout.

## July 16, 2026

* Added a separate Rounded-filter branch based on 2.4u.
* Changed the default Rev 1/2 target from RePro Driven to RePro Rounded; Rev 3 remains Poly.
* Replaced the analyzer-derived Rev 1/2-to-Rounded resonance lookup with a musical, patch-anchored curve.
* Used Better Ways to set the middle of the curve near Rounded 46 and Bell Tree to restore the maximum endpoint to Rounded 72.
* Treated Rounded self-oscillation onset near 68 as a behavioral landmark rather than trying to infer it from spectral peak lift.
* Retained the existing measured Rev 1/2-to-Rounded cutoff mapping.
* Added explicit temporary Rounded aliases for the existing Rev 1/2 envelope-depth and Poly Mod filter curves so unrelated behavior does not silently fall back.

* Corrected patch-location metadata to match Prophet Rev 4 hardware organization: User 1-5 and Factory 1-5, each with Groups 1-5 and Programs 1-8.
* Retained the source SysEx bank filename before the corrected hardware location in each RePro Description field.

* Fixed normal Osc B tuning for SoundTower coarse labels ending in `+`. These labels share the same hardware base pitch as the matching non-`+` note and no longer add a false half-semitone or octave-boundary carry.
* Combined the corrected Osc B coarse pitch with the measured unipolar Fine Tune sharpening before normalizing it relative to RePro-5's C-based oscillator pitch.
* Corrected official factory-bank indexing. For example, Fat Poly Bass is now identified as Factory 2 1-6.
* Added each source patch location to the RePro preset Description metadata for faster hardware validation.
* Replaced the linear Standard LFO Frequency mapping with a measured Prophet Rev 4-to-RePro rate mapping.
* Matched hardware and RePro controls in logarithmic rate space rather than by knob position.
* Used the highest measured rate where duplicate hardware readings shifted slightly.
* Extrapolated the unmeasurable hardware endpoints at raw 0 and 120; the top endpoint clamps to RePro 100.
* Retained the calibrated Osc B Low Frequency mapping from v2.4r.

## July 15, 2026

* Added measured Osc B Poly Mod source-to-filter mappings for Rev 3-to-Poly and Rev 1/2-to-Driven.
* Added a midpoint compromise when Osc B simultaneously modulates Osc A Frequency and Filter, since RePro has one shared Osc B Voice Mod amount.
* Included the complete four-set Poly Mod measurement reference and updated routing notes.

## July 14, 2026

* Replaced the coarse Osc B Poly Mod source curve with a full 21-point hardware-to-RePro pitch-depth mapping.
* Added measured Filter Envelope Poly Mod mappings for Osc A Frequency and for Rev 3-to-Poly and Rev 1/2-to-Driven filter destinations.
* Added destination-aware Poly Mod routing, with filter-safe priority when Filter and Osc A Frequency are enabled together.
* Standardized measured Poly Mod amount controls on the complete Prophet/SoundTower 0-120 range.
* Included the complete three-set Poly Mod measurement reference and mapping notes in the package.

## July 13, 2026

* Added separate measured Filter Envelope Depth mappings for Rev 3 hardware to RePro Poly and Rev 1/2 hardware to RePro Driven.
* Matched Filter Envelope Depth by self-oscillation sweep distance from a shared 54.1 Hz base across the complete 0-120 Prophet/SoundTower parameter range.
* Separated filter and amplifier envelope mappings so each uses its own measurements.
* Replaced filter Attack, Decay, Sustain, and Release mappings with measured lookup/interpolation curves.

## July 3, 2026

* Removed preset metadata from the bundled template.
* Replaced the bundled RePro-5 init template with a RePro-saved preset so the FX chain order is preserved by RePro-5 when presets load. The intended default order is Velvet, Lyrebird, ResQ, Drench, and Sonic Conditioner. FX remain bypassed/off by default.

## July 2, 2026

* Improved Osc B Fine Tune mapping using measured Prophet Rev 4 pitch offsets.
* Changed larger Osc B Fine Tune offsets to use RePro Osc B Frequency instead of forcing everything through RePro Osc B Fine Tune.
* Added a RePro Mixer Noise default of 0.3 when Prophet Noise is off to better match hardware behavior.
* Updated Glide Time mapping to better match hardware.
* Updated the intended RePro FX order/configuration to Velvet, Lyrebird, ResQ, Drench, and Sonic Conditioner. FX remain bypassed/off by default.
* Validated PWM mapping against hardware. No changes needed.

## July 1, 2026

* Updated Resonance mapping separately for Rev 3/Poly and Rev 1/2/Driven filter behavior. This helps compensate for RePro-5 reaching stronger resonance at equivalent settings.
* Updated Amp Velocity On to use RePro Amp Envelope Velocity Depth 100 to better match hardware.
* Updated Filter Velocity On to use RePro Filter Envelope Velocity Depth 91 to better match hardware.
* Updated Filter Envelope Amount mapping using measured hardware-to-RePro comparison points.
* Added Prophet/SoundTower-style patch locations, such as Factory 2 5-6, to the report for easier patch lookup.

## June 30, 2026

* Updated Filter Cutoff mapping separately for Rev 3/Poly and Rev 1/2/Driven filter behavior.
* Added measured Attack, Decay, and Release envelope time mappings to better match hardware.
* Updated Vintage/Detune mapping to better match tighter and driftier Prophet behavior.
* Added oscillator top-end clamping so high Prophet oscillator frequency values do not overshoot the hardware’s maximum pitch.

## June 29, 2026

* Added stack/split program handling.
* Added clearer filename templates for exported RePro patches.
* Added patch-name cleanup for title casing, acronyms, decade forms, ordinals, and other case issues.

## June 28, 2026

* Initial version.
* Added initial Rev 1/2 vs Rev 3 filter model selection, using RePro Driven for Rev 1/2-style patches and RePro Poly for Rev 3-style patches.
* Fixed the oscillator octave mapping offset.
* Added smart output-level mapping to reduce overly loud or overly quiet converted patches.
* Added output adjustment based on mixer level, filter openness, resonance, envelopes, and unison behavior.
* Added expanded conversion reporting for easier patch comparison and debugging.
