@echo off
setlocal
cd /d "%~dp0"

if not exist "p5rev4_to_repro5.py" (
    echo ERROR: p5rev4_to_repro5.py was not found in this folder.
    pause
    exit /b 1
)

dir /b "*.syx" >nul 2>&1
if errorlevel 1 (
    echo No .syx files were found in this folder.
    echo Copy your Prophet SysEx files here, then run this batch file again.
    pause
    exit /b 1
)

where py >nul 2>&1
if not errorlevel 1 (
    py ".\p5rev4_to_repro5.py" --all-syx --profile ".\p5rev4_to_repro5_profile.json" --out ".\Converted_RePro5_All_2_5_14" --filename-template "{name}"
    set "RESULT=%ERRORLEVEL%"
    goto finished
)

where python >nul 2>&1
if not errorlevel 1 (
    python ".\p5rev4_to_repro5.py" --all-syx --profile ".\p5rev4_to_repro5_profile.json" --out ".\Converted_RePro5_All_2_5_14" --filename-template "{name}"
    set "RESULT=%ERRORLEVEL%"
    goto finished
)

echo ERROR: Python 3 was not found.
echo Install Python 3, then run this batch file again.
set "RESULT=1"

:finished
echo.
if "%RESULT%"=="0" (
    echo Conversion complete.
    echo Output folder: Converted_RePro5_All_2_5_14
) else (
    echo Conversion failed with error code %RESULT%.
)
echo.
pause
exit /b %RESULT%
