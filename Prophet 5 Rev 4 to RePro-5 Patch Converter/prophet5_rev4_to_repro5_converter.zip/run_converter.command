#!/bin/sh

cd "$(dirname "$0")" || exit 1

if [ ! -f "./p5rev4_to_repro5.py" ]; then
    echo "ERROR: p5rev4_to_repro5.py was not found in this folder."
    printf "Press Enter to close..."
    read _answer
    exit 1
fi

set -- ./*.syx
if [ ! -e "$1" ]; then
    echo "No .syx files were found in this folder."
    echo "Copy your Prophet SysEx files here, then run this launcher again."
    printf "Press Enter to close..."
    read _answer
    exit 1
fi

if command -v python3 >/dev/null 2>&1; then
    PYTHON_CMD="python3"
elif command -v python >/dev/null 2>&1; then
    PYTHON_CMD="python"
else
    echo "ERROR: Python 3 was not found."
    echo "Install Python 3, then run this launcher again."
    printf "Press Enter to close..."
    read _answer
    exit 1
fi

"$PYTHON_CMD" "./p5rev4_to_repro5.py" \
    --all-syx \
    --profile "./p5rev4_to_repro5_profile.json" \
    --out "./Converted_RePro5_All_2_5_14" \
    --filename-template "{name}"

RESULT=$?
echo
if [ "$RESULT" -eq 0 ]; then
    echo "Conversion complete."
    echo "Output folder: Converted_RePro5_All_2_5_14"
else
    echo "Conversion failed with error code $RESULT."
fi

printf "Press Enter to close..."
read _answer
exit "$RESULT"
